const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { setXp, totalXpForLevel } = require('../utils/xp');

const OWNER_ID = '1385961376656134257';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setxp')
    .setDescription("Owner only: set a user's XP or level in this server")
    .addUserOption(o => o.setName('user').setDescription('Whose XP?').setRequired(true))
    .addIntegerOption(o =>
      o.setName('xp').setDescription('Set total XP to this amount')
        .setMinValue(0).setMaxValue(2000000000))
    .addIntegerOption(o =>
      o.setName('level').setDescription('Set the level (XP is set to the start of that level)')
        .setMinValue(0).setMaxValue(500))
    .setDefaultMemberPermissions(0)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;

    if (interaction.user.id !== OWNER_ID)
      return interaction.reply({ content: 'Only the bot owner can use this command.', flags: ephemeral });

    const user = interaction.options.getUser('user');
    const xp = interaction.options.getInteger('xp');
    const level = interaction.options.getInteger('level');

    if (user.bot)
      return interaction.reply({ content: "Bots don't earn XP.", flags: ephemeral });
    if (xp === null && level === null)
      return interaction.reply({ content: 'Provide either `xp` or `level`.', flags: ephemeral });
    if (xp !== null && level !== null)
      return interaction.reply({ content: 'Provide only one of `xp` or `level`, not both.', flags: ephemeral });

    const target = xp !== null ? xp : totalXpForLevel(level);
    const info = setXp(interaction.guild.id, user.id, target);

    await interaction.reply({
      content: `📈 **${user.username}** is now level **${info.level}** with **${target.toLocaleString('en-US')}** total XP in this server.`,
      flags: ephemeral,
      allowedMentions: { parse: [] },
    });
  },
};