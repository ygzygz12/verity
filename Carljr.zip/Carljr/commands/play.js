const path = require('path');
const { SlashCommandBuilder, MessageFlags, escapeMarkdown } = require('discord.js');
const music = require('../utils/music');
const ytdlp = require('../utils/ytdlp');

function fmtDuration(s) {
  if (!s) return '';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  const pad = n => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(sec)}` : `${m}:${pad(sec)}`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Plays a YouTube link or search, a music file, or a direct audio link')
    .addStringOption(o =>
      o.setName('query').setDescription('YouTube link, search text, file name or direct audio link')
        .setRequired(true).setAutocomplete(true).setMaxLength(500))
    .setIntegrationTypes(0)
    .setContexts(0),
  async autocomplete(interaction) {
    const focused = interaction.options.getFocused().toLowerCase();
    const files = music.listFiles().filter(f => f.toLowerCase().includes(focused)).slice(0, 25);
    await interaction.respond(files.map(f => ({ name: f, value: f })));
  },
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;
    const noPing = { parse: [] };
    const query = interaction.options.getString('query').trim();

    const check = music.checkUser(interaction);
    if (check.error) return interaction.reply({ content: check.error, flags: ephemeral });

    let track = null;
    let needsYoutube = false;

    if (/^https?:\/\//i.test(query)) {
      try {
        new URL(query);
      } catch {
        return interaction.reply({ content: 'That link is not valid.', flags: ephemeral });
      }
      if (ytdlp.isYoutubeUrl(query)) {
        needsYoutube = true;
      } else {
        track = {
          kind: 'url',
          source: query,
          title: escapeMarkdown(music.titleFromUrl(query)),
          requestedBy: interaction.user.username,
        };
      }
    } else {
      const file = music.listFiles().find(f => f === query);
      if (file) {
        track = {
          kind: 'file',
          source: path.join(music.MUSIC_DIR, file),
          title: escapeMarkdown(file.replace(/\.[^.]+$/, '')),
          requestedBy: interaction.user.username,
        };
      } else {
        needsYoutube = true;
      }
    }

    await interaction.deferReply();

    if (needsYoutube) {
      await interaction.editReply({ content: '🔎 Looking it up on YouTube...', allowedMentions: noPing });
      try {
        const info = await ytdlp.getInfo(query);
        track = {
          kind: 'youtube',
          source: info.url,
          title: escapeMarkdown(info.title).slice(0, 100),
          duration: info.duration,
          requestedBy: interaction.user.username,
        };
      } catch (err) {
        console.error('YouTube lookup error:', err.message);
        return interaction.editReply({
          content: `⚠️ ${err.user ? err.message : 'The YouTube lookup failed.'}`,
          allowedMentions: noPing,
        });
      }
    }

    let session = check.session;
    if (!session) {
      if (!check.channel.joinable || !check.channel.speakable)
        return interaction.editReply({ content: "I don't have permission to join and speak in that voice channel.", allowedMentions: noPing });
      try {
        session = await music.createSession(interaction, check.channel);
      } catch (err) {
        console.error('Join error:', err.message);
        return interaction.editReply({ content: `⚠️ ${err.user ? err.message : 'I could not join the voice channel.'}`, allowedMentions: noPing });
      }
    }

    const pos = music.addTrack(session, track);
    if (pos === -1)
      return interaction.editReply({ content: `The queue is full (${music.MAX_QUEUE} tracks).`, allowedMentions: noPing });

    const length = track.duration ? ` (${fmtDuration(track.duration)})` : '';
    await interaction.editReply({
      content: pos === 0
        ? `🎶 Starting **${track.title}**${length}...`
        : `➕ Added **${track.title}**${length} to the queue (position ${pos}).`,
      allowedMentions: noPing,
    });
  },
};