const { SlashCommandBuilder, MessageFlags } = require('discord.js');

const MESSAGE = [
  '🇦🇿 AZERBAYCAN FAMILY 🇦🇿',
  '',
  'Aile arıyorsan, buldun!',
  '',
  '💬 7/24 aktif sohbet, samimi ortam',
  '🔄 Güvenli Trade odaları',
  '⚖️ WFL - Trade\'inin değerini öğren',
  '🎁 Sürekli ÇEKİLİŞLER',
  '🎮 Oyun, müzik, eğlence',
  '',
  'Yalnız değilsin, sen de ailedensin!',
  '👑 Yerini şimdi kap!',
  '',
  '🔗 https://discord.gg/4vSZgGXhY',
].join('\n');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('azerbaycanfamily')
    .setDescription('Azerbaycan Family sunucusu hakkında bilgi')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    await interaction.reply({ content: MESSAGE, flags: MessageFlags.Ephemeral });
  },
};