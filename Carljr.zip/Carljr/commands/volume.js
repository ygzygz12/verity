const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Sets the music volume')
    .addIntegerOption(o =>
      o.setName('percent').setDescription('Volume from 1 to 100').setMinValue(1).setMaxValue(100).setRequired(true))
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });

    const percent = interaction.options.getInteger('percent');
    music.setVolume(check.session, percent);
    await interaction.reply(`🔊 Volume set to **${percent}%**.`);
  },
};