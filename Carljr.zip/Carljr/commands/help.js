const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');

const CATEGORIES = {
  'Moderation (servers only)': ['ban', 'kick', 'timeout', 'untimeout', 'clear', 'warn', 'warnings', 'delwarn', 'clearwarns', 'lock', 'unlock', 'setlog', 'unban',],
  'Fun': ['funnyvideo','poll',],
  'Ai': ['ask'],
  'Utility': ['ping', 'help', 'suggestion','serverinfo','userinfo','avatar','azerbaycanfamily[AD]'],
  'Economy': ['balance', 'daily', 'work', 'pay', 'leaderboard'],
  'Levels': ['rank', 'levels'],
  'Economy': ['balance', 'daily', 'work', 'pay', 'rob', 'deposit', 'withdraw', 'shop', 'buy', 'leaderboard'],
  'Music': ['join', 'play', 'pause', 'resume', 'skip', 'queue', 'nowplaying', 'loop', 'shuffle', 'remove', 'clearqueue', 'volume', 'stop'],
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Shows all commands')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const all = interaction.client.commands;
    const used = new Set();
    const fields = [];

    for (const [category, names] of Object.entries(CATEGORIES)) {
      const lines = names
        .filter(n => all.has(n))
        .map(n => {
          used.add(n);
          return `\`/${n}\` - ${all.get(n).data.description}`;
        });
      if (lines.length) fields.push({ name: category, value: lines.join('\n') });
    }

    const others = [...all.values()]
      .filter(c => !used.has(c.data.name))
      .map(c => `\`/${c.data.name}\` - ${c.data.description}`);
    if (others.length) fields.push({ name: 'Other', value: others.join('\n').slice(0, 1024) });

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`${interaction.client.user.username} - Commands`)
      .setDescription('Here is everything I can do. Moderation commands only appear for members with the right permissions.')
      .addFields(fields)
      .setFooter({ text: `${all.size} commands` });

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};