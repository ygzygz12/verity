const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, withdraw } = require('../utils/economy');

const fmt = n => n.toLocaleString('en-US');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('withdraw')
    .setDescription('Take coins out of the bank into your wallet')
    .addStringOption(o =>
      o.setName('amount').setDescription("A number, or 'all'").setRequired(true).setMaxLength(20))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;
    const raw = interaction.options.getString('amount').trim().toLowerCase();

    let amount = null;
    if (raw !== 'all' && raw !== 'max') {
      const clean = raw.replace(/[,_\s]/g, '');
      if (!/^\d{1,12}$/.test(clean) || Number(clean) < 1)
        return interaction.reply({ content: "Enter a positive number or `all`.", flags: ephemeral });
      amount = Number(clean);
    }

    const res = withdraw(interaction.user.id, amount);
    switch (res.status) {
      case 'empty':
        return interaction.reply({ content: `You have no ${CURRENCY.name} in the bank.`, flags: ephemeral });
      case 'not_enough':
        return interaction.reply({ content: `You only have **${fmt(res.bank)}** ${CURRENCY.name} in the bank.`, flags: ephemeral });
      case 'ok':
        return interaction.reply({
          content: `🏦 Withdrew **${fmt(res.moved)}** ${CURRENCY.name}.\nWallet: **${fmt(res.balance)}** | Bank: **${fmt(res.bank)}**`,
          flags: ephemeral,
        });
    }
  },
};