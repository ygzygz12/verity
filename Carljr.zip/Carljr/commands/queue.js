const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

const LOOP_TEXT = { off: 'Off', track: 'Current track', queue: 'Whole queue' };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Shows the music queue')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const session = music.getSession(interaction.guild.id);
    if (!session?.current)
      return interaction.reply({ content: 'Nothing is playing right now.', flags: MessageFlags.Ephemeral });

    const next = session.queue.slice(0, 10).map((t, i) => `**${i + 1}.** ${t.title} (by ${t.requestedBy})`);
    const more = session.queue.length > 10 ? `\n...and ${session.queue.length - 10} more` : '';

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('Music queue')
      .setDescription(
        `${music.isPaused(session) ? '⏸️' : '🎶'} **Now:** ${session.current.title} (by ${session.current.requestedBy})\n\n` +
        (next.length ? `**Up next:**\n${next.join('\n')}${more}` : 'The queue is empty.')
      )
      .setFooter({ text: `Loop: ${LOOP_TEXT[session.loop]} | Volume: ${Math.round(session.volume * 100)}%` });

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};