const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, transfer } = require('../utils/economy');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Send coins to another user')
    .addUserOption(o => o.setName('user').setDescription('Who gets the coins?').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('How many?').setMinValue(1).setRequired(true))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const ephemeral = MessageFlags.Ephemeral;

    if (target.bot)
      return interaction.reply({ content: "Bots don't need money.", flags: ephemeral });
    if (target.id === interaction.user.id)
      return interaction.reply({ content: "You can't pay yourself.", flags: ephemeral });
    if (!transfer(interaction.user.id, target.id, amount))
      return interaction.reply({ content: "You don't have enough coins.", flags: ephemeral });

    await interaction.reply(`**${interaction.user.username}** sent **${amount.toLocaleString('en-US')}** ${CURRENCY.name} to **${target.username}**.`);
  },
};