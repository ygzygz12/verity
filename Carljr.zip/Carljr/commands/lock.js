const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { logAction } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Locks a channel so members cannot send messages')
    .addChannelOption(o =>
      o.setName('channel').setDescription('Channel to lock (default: current channel)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setMaxLength(300))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') ?? interaction.channel;
    const reason = interaction.options.getString('reason') ?? 'No reason provided';
    const everyone = interaction.guild.roles.everyone;

    if (!channel.permissionsFor(interaction.guild.members.me).has(PermissionFlagsBits.ManageChannels))
      return interaction.reply({ content: "I don't have permission to manage that channel.", flags: MessageFlags.Ephemeral });

    if (channel.permissionOverwrites.cache.get(everyone.id)?.deny.has(PermissionFlagsBits.SendMessages))
      return interaction.reply({ content: `${channel} is already locked.`, flags: MessageFlags.Ephemeral });

    await channel.permissionOverwrites.edit(everyone, {
      SendMessages: false,
      SendMessagesInThreads: false,
      CreatePublicThreads: false,
      CreatePrivateThreads: false,
    }, { reason: `${interaction.user.tag}: ${reason}` });

    await logAction(interaction, { action: '🔒 Channel locked', color: 0xed4245, target: `${channel}`, reason });
    await interaction.reply(`🔒 ${channel} has been locked. Reason: ${reason}`);
  },
};