const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { CURRENCY, top } = require('../utils/economy');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Shows the richest users')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const list = top(10);
    if (!list.length) return interaction.reply('Nobody has any coins yet. Try `/daily`!');

    const medals = ['🥇', '🥈', '🥉'];
    const lines = list.map((u, i) =>
      `${medals[i] ?? `**${i + 1}.**`} <@${u.id}> - ${u.balance.toLocaleString('en-US')} ${CURRENCY.emoji}`);

    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('Leaderboard')
      .setDescription(lines.join('\n'));

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};