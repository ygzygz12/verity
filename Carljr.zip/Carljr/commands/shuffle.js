const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shuffle')
    .setDescription('Shuffles the queue')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });
    if (check.session.queue.length < 2)
      return interaction.reply({ content: 'You need at least 2 tracks in the queue to shuffle.', flags: MessageFlags.Ephemeral });

    const count = music.shuffleQueue(check.session);
    await interaction.reply(`🔀 Shuffled ${count} tracks.`);
  },
};