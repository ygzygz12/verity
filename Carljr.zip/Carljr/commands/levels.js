const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { top } = require('../utils/xp');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('levels')
    .setDescription('Shows the XP leaderboard of this server')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const list = top(interaction.guild.id, 10);
    if (!list.length)
      return interaction.reply('Nobody has earned XP here yet. Start chatting!');

    const medals = ['🥇', '🥈', '🥉'];
    const lines = list.map((u, i) =>
      `${medals[i] ?? `**${i + 1}.**`} <@${u.id}> - Level ${u.level} (${u.xp.toLocaleString('en-US')} XP)`);

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`${interaction.guild.name} - Levels`)
      .setDescription(lines.join('\n'));

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};