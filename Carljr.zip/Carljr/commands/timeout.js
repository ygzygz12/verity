const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Bir kullanıcıyı susturur')
    .addUserOption(o => o.setName('kullanici').setDescription('Susturulacak kullanıcı').setRequired(true))
    .addIntegerOption(o =>
      o.setName('dakika').setDescription('Süre (dakika, en fazla 40320)')
        .setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(o => o.setName('sebep').setDescription('Sebep'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const minutes = interaction.options.getInteger('dakika');
    const reason = interaction.options.getString('sebep') ?? 'Sebep belirtilmedi';
    const ephemeral = MessageFlags.Ephemeral;

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member)
      return interaction.reply({ content: 'Bu kullanıcı sunucuda değil.', flags: ephemeral });
    if (user.id === interaction.user.id)
      return interaction.reply({ content: 'Kendini susturamazsın.', flags: ephemeral });

    const isOwner = interaction.guild.ownerId === interaction.user.id;
    if (!isOwner && interaction.member.roles.highest.position <= member.roles.highest.position)
      return interaction.reply({ content: 'Rolü senden yüksek veya eşit birini susturamazsın.', flags: ephemeral });
    if (!member.moderatable)
      return interaction.reply({ content: 'Bu kullanıcıyı susturamıyorum (rolü benden yüksek veya yönetici olabilir).', flags: ephemeral });

    await member.timeout(minutes * 60 * 1000, `${interaction.user.tag}: ${reason}`);
    await logAction(interaction, { action: '🔇 Timeout', color: 0xfee75c, target: fmtUser(user), reason, details: `${minutes} minutes` });
    await interaction.reply(`🔇 **${user.tag}** ${minutes} dakika susturuldu. Sebep: ${reason}`);
  },
};