const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { clearWarns } = require('../utils/warns');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearwarns')
    .setDescription('Bir kullanıcının tüm uyarılarını siler')
    .addUserOption(o => o.setName('kullanici').setDescription('Kullanıcı').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const count = clearWarns(interaction.guild.id, user.id);

    if (!count)
      return interaction.reply(`**${user.tag}** kullanıcısının silinecek uyarısı yok.`);

    await logAction(interaction, { action: '🧹 Warns cleared', color: 0x57f287, target: fmtUser(user), details: `${count} warns removed` });
    await interaction.reply(`🧹 **${user.tag}** kullanıcısının ${count} uyarısı silindi.`);
  },
};