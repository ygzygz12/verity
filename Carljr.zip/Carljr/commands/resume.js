const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Resumes the music')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });
    if (!music.isPaused(check.session))
      return interaction.reply({ content: "It's not paused.", flags: MessageFlags.Ephemeral });

    check.session.player.unpause();
    await interaction.reply('▶️ Resumed.');
  },
};