const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Creates a poll')
    .addStringOption(o =>
      o.setName('question').setDescription('The poll question').setRequired(true).setMaxLength(300))
    .addStringOption(o =>
      o.setName('option1').setDescription('First option').setRequired(true).setMaxLength(55))
    .addStringOption(o =>
      o.setName('option2').setDescription('Second option').setRequired(true).setMaxLength(55))
    .addStringOption(o => o.setName('option3').setDescription('Third option').setMaxLength(55))
    .addStringOption(o => o.setName('option4').setDescription('Fourth option').setMaxLength(55))
    .addStringOption(o => o.setName('option5').setDescription('Fifth option').setMaxLength(55))
    .addIntegerOption(o =>
      o.setName('duration').setDescription('How long the poll stays open (default: 24 hours)')
        .addChoices(
          { name: '1 hour', value: 1 },
          { name: '4 hours', value: 4 },
          { name: '8 hours', value: 8 },
          { name: '24 hours', value: 24 },
          { name: '3 days', value: 72 },
          { name: '1 week', value: 168 },
        ))
    .addBooleanOption(o =>
      o.setName('multiple').setDescription('Allow people to pick more than one option'))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const answers = [1, 2, 3, 4, 5]
      .map(i => interaction.options.getString(`option${i}`))
      .filter(Boolean)
      .map(text => ({ text }));

    try {
      await interaction.reply({
        poll: {
          question: { text: interaction.options.getString('question') },
          answers,
          duration: interaction.options.getInteger('duration') ?? 24,
          allowMultiselect: interaction.options.getBoolean('multiple') ?? false,
        },
      });
    } catch (err) {
      console.error(err);
      await interaction.reply({
        content: "I couldn't create the poll. Make sure I have the **Send Polls** permission in this channel.",
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    }
  },
};