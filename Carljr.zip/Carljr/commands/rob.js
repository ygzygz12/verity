const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, rob } = require('../utils/economy');

const OPTIONS = {
  cooldownMs: 60 * 60 * 1000,  // 1 hour between attempts
  shieldMs: 30 * 60 * 1000,    // a robbed user is protected for 30 minutes
  chance: 0.5,                 // 50% success chance
  minBalance: 200,             // both players need at least this much
  maxSteal: 5000,              // maximum stolen in one robbery
  fineRatio: 0.6,              // failed robbery costs 60% of the attempted amount
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription("Try to steal coins from someone (risky!)")
    .addUserOption(o => o.setName('user').setDescription('Who do you want to rob?').setRequired(true))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const ephemeral = MessageFlags.Ephemeral;

    if (target.bot)
      return interaction.reply({ content: "Bots don't carry any coins.", flags: ephemeral });
    if (target.id === interaction.user.id)
      return interaction.reply({ content: "You can't rob yourself.", flags: ephemeral });

    const res = rob(interaction.user.id, target.id, OPTIONS);
    const fmt = n => n.toLocaleString('en-US');
    const when = ms => Math.floor((Date.now() + ms) / 1000);

    switch (res.status) {
      case 'cooldown':
        return interaction.reply({ content: `You're lying low. You can rob again <t:${when(res.remaining)}:R>.`, flags: ephemeral });
      case 'shield':
        return interaction.reply({ content: `**${target.username}** was robbed recently and is protected until <t:${when(res.remaining)}:R>.`, flags: ephemeral });
      case 'thief_poor':
        return interaction.reply({ content: `You need at least ${fmt(OPTIONS.minBalance)} ${CURRENCY.name} to try robbing someone.`, flags: ephemeral });
      case 'victim_poor':
        return interaction.reply({ content: `**${target.username}** doesn't have enough ${CURRENCY.name} to be worth robbing.`, flags: ephemeral });
      case 'success':
        return interaction.reply({
          content: `🦹 You robbed **${target.username}** and got away with **${fmt(res.amount)}** ${CURRENCY.name}! Balance: **${fmt(res.balance)}**`,
          allowedMentions: { parse: [] },
        });
      case 'fail':
        return interaction.reply({
          content: `🚨 You got caught robbing **${target.username}** and paid them **${fmt(res.amount)}** ${CURRENCY.name} as a fine. Balance: **${fmt(res.balance)}**`,
          allowedMentions: { parse: [] },
        });
    }
  },
};