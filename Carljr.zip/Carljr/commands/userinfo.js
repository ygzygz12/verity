const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Shows information about a user')
    .addUserOption(o => o.setName('user').setDescription('Which user? (default: you)'))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const picked = interaction.options.getUser('user') ?? interaction.user;
    const user = await picked.fetch().catch(() => picked);
    const member = interaction.options.getMember('user') ??
      (picked.id === interaction.user.id ? interaction.member : null);

    const created = Math.floor(user.createdTimestamp / 1000);
    const lines = [
      `**Username:** ${user.username}`,
      `**Display name:** ${user.globalName ?? user.username}`,
      `**ID:** ${user.id}`,
      `**Bot:** ${user.bot ? 'Yes' : 'No'}`,
      `**Account created:** <t:${created}:D> (<t:${created}:R>)`,
    ];

    const badges = user.flags?.toArray() ?? [];
    if (badges.length) lines.push(`**Badges:** ${badges.join(', ')}`);

    const embed = new EmbedBuilder()
      .setColor(user.accentColor ?? 0x5865f2)
      .setTitle(user.username)
      .setThumbnail(user.displayAvatarURL({ size: 512 }))
      .setDescription(lines.join('\n'));

    if (member?.joinedTimestamp) {
      const joined = Math.floor(member.joinedTimestamp / 1000);
      const roles = member.roles.cache
        .filter(r => r.id !== interaction.guild.id)
        .sort((a, b) => b.position - a.position)
        .map(r => `${r}`);

      embed.addFields(
        { name: 'Joined server', value: `<t:${joined}:D> (<t:${joined}:R>)` },
        { name: `Roles (${roles.length})`, value: roles.length ? roles.slice(0, 15).join(' ') + (roles.length > 15 ? ` +${roles.length - 15} more` : '') : 'None' },
      );
      if (member.nickname) embed.addFields({ name: 'Nickname', value: member.nickname });
    }

    if (user.bannerURL()) embed.setImage(user.bannerURL({ size: 1024 }));

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};