const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Pauses the music')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });
    if (!check.session.current)
      return interaction.reply({ content: 'Nothing is playing.', flags: MessageFlags.Ephemeral });
    if (music.isPaused(check.session))
      return interaction.reply({ content: 'Already paused. Use `/resume`.', flags: MessageFlags.Ephemeral });

    check.session.player.pause();
    await interaction.reply('⏸️ Paused.');
  },
};