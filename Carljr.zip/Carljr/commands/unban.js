const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unbans a user')
    .addStringOption(o =>
      o.setName('user_id').setDescription('ID of the banned user').setRequired(true).setMinLength(17).setMaxLength(20))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setMaxLength(300))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const id = interaction.options.getString('user_id').trim();
    const reason = interaction.options.getString('reason') ?? 'No reason provided';
    const ephemeral = MessageFlags.Ephemeral;

    if (!/^\d{17,20}$/.test(id))
      return interaction.reply({ content: 'That is not a valid user ID. IDs are numbers only.', flags: ephemeral });

    const ban = await interaction.guild.bans.fetch(id).catch(() => null);
    if (!ban)
      return interaction.reply({ content: 'That user is not banned in this server.', flags: ephemeral });

    await interaction.guild.members.unban(id, `${interaction.user.tag}: ${reason}`);
    await logAction(interaction, { action: '✅ Unban', color: 0x57f287, target: fmtUser(ban.user), reason });
    await interaction.reply(`✅ **${ban.user.tag}** was unbanned. Reason: ${reason}`);
  },
};