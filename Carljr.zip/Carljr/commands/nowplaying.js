const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

const LOOP_TEXT = { off: 'Off', track: 'Current track', queue: 'Whole queue' };

function fmt(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  const pad = n => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(sec)}` : `${m}:${pad(sec)}`;
}

function bar(elapsed, total, size = 14) {
  const pos = Math.min(size - 1, Math.floor((elapsed / total) * size));
  return '▬'.repeat(pos) + '🔘' + '▬'.repeat(size - 1 - pos);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nowplaying')
    .setDescription('Shows the track that is playing right now')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const session = music.getSession(interaction.guild.id);
    if (!session?.current)
      return interaction.reply({ content: 'Nothing is playing right now.', flags: MessageFlags.Ephemeral });

    const t = session.current;
    const elapsed = music.elapsedSeconds(session);

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(music.isPaused(session) ? '⏸️ Paused' : '🎶 Now playing')
      .setDescription(`**${t.title}**`)
      .addFields(
        { name: 'Requested by', value: t.requestedBy, inline: true },
        { name: 'Loop', value: LOOP_TEXT[session.loop], inline: true },
        { name: 'Volume', value: `${Math.round(session.volume * 100)}%`, inline: true },
      );

    if (t.duration)
      embed.addFields({ name: 'Progress', value: `${bar(elapsed, t.duration)}\n${fmt(elapsed)} / ${fmt(t.duration)}` });
    else
      embed.addFields({ name: 'Played', value: fmt(elapsed) });

    if (t.kind === 'youtube') embed.setURL(t.source);

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};