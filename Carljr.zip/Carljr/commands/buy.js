const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, BANK_UPGRADE_MAX } = require('../utils/economy');
const { ITEMS, BOX_TEXT, buyItem } = require('../utils/shop');

const fmt = n => n.toLocaleString('en-US');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Buy something from the shop')
    .addStringOption(o =>
      o.setName('item').setDescription('What do you want to buy?').setRequired(true)
        .addChoices(...Object.entries(ITEMS).map(([value, i]) => ({
          name: `${i.name} (${fmt(i.price)} coins)`,
          value,
        }))))
    .addIntegerOption(o =>
      o.setName('amount').setDescription('How many? (default: 1, max 10)').setMinValue(1).setMaxValue(10))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const key = interaction.options.getString('item');
    const amount = interaction.options.getInteger('amount') ?? 1;
    const item = ITEMS[key];
    if (!item)
      return interaction.reply({ content: 'That item does not exist.', flags: MessageFlags.Ephemeral });

    const results = [];
    let stop = null;
    for (let i = 0; i < amount; i++) {
      const res = buyItem(interaction.user.id, key);
      if (res.status === 'ok') results.push(res);
      else {
        stop = res;
        break;
      }
    }

    const why = res => {
      if (res.status === 'poor')
        return `You need **${fmt(item.price)}** ${CURRENCY.name} in your wallet but only have **${fmt(res.balance)}**. Coins in the bank can't be spent, use \`/withdraw\` first.`;
      if (res.status === 'refused') return res.reason;
      return 'Something went wrong.';
    };

    if (!results.length)
      return interaction.reply({ content: why(stop), flags: MessageFlags.Ephemeral });

    const last = results.at(-1);
    const spent = results.length * item.price;
    let text;

    if (key === 'mystery_box') {
      const lines = results.map(r => `${item.emoji} +**${fmt(r.reward)}** - ${BOX_TEXT[r.tier]}`);
      const won = results.reduce((sum, r) => sum + r.reward, 0);
      const net = won - spent;
      text =
        `${item.emoji} Opened **${results.length}** ${item.name}${results.length > 1 ? 'es' : ''} for **${fmt(spent)}** ${CURRENCY.name}.\n` +
        `${lines.join('\n')}\n` +
        `You won **${fmt(won)}** ${CURRENCY.name} (net ${net >= 0 ? '+' : '-'}${fmt(Math.abs(net))}). Wallet: **${fmt(last.balance)}**`;
    } else {
      text =
        `${item.emoji} Bought **${results.length}** ${item.name}${results.length > 1 ? 's' : ''} for **${fmt(spent)}** ${CURRENCY.name}.\n` +
        `Bank limit: **${fmt(last.limit)}** (upgrades: ${last.upgrades}/${BANK_UPGRADE_MAX}). Wallet: **${fmt(last.balance)}**`;
    }

    if (stop) text += `\n⚠️ Stopped early: ${why(stop)}`;

    await interaction.reply(text);
  },
};