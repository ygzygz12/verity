const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, tryRemove, addBalance } = require('../utils/economy');

const SPIN = '<a:spin:1561879579113824297>';
const TAILS = '<:tails:1561879608654176317>';
const HEADS = '<:heads:1561879631274049636>';

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flips a coin (optionally with a bet)')
    .addStringOption(o =>
      o.setName('guess').setDescription('Heads or tails?')
        .addChoices(
          { name: 'Heads', value: 'heads' },
          { name: 'Tails', value: 'tails' },
        ))
    .addIntegerOption(o =>
      o.setName('bet').setDescription('Coins to bet (needs a guess)').setMinValue(1))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const guess = interaction.options.getString('guess');
    const bet = interaction.options.getInteger('bet');

    if (bet && !guess)
      return interaction.reply({ content: 'Pick heads or tails to place a bet.', flags: MessageFlags.Ephemeral });
    if (bet && !tryRemove(interaction.user.id, bet))
      return interaction.reply({ content: "You don't have enough coins for that bet.", flags: MessageFlags.Ephemeral });

    const result = Math.random() < 0.5 ? 'heads' : 'tails';

    await interaction.reply(`${SPIN} Flipping the coin...`);
    await sleep(1500);

    let text = `${result === 'heads' ? HEADS : TAILS} The coin landed on **${result}**!`;
    if (guess) {
      const won = guess === result;
      text += won ? ' You guessed right! ' : ' Wrong guess, better luck next time';
      if (bet) {
        if (won) addBalance(interaction.user.id, bet * 2);
        text += won
          ? `\nYou won **${bet.toLocaleString('en-US')}** ${CURRENCY.name}!`
          : `\nYou lost **${bet.toLocaleString('en-US')}** ${CURRENCY.name}.`;
      }
    }

    await interaction.editReply(text);
  },
};