const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder } = require('discord.js');

const VIDEOS = [
  'https://cdn.discordapp.com/attachments/1387874727598755873/1538564404839448727/m2-res_498p.mp4?ex=6ad78343&is=6ad631c3&hm=26f665152495944523bfeb9af1768e77a92b2d4787100fe1dc59c38961580e0a&',
  'https://cdn.discordapp.com/attachments/1387874727598755873/1538564689590620170/m2-res_20p.mp4?ex=6ad78387&is=6ad63207&hm=93d1a73c38d9880ed45c6ceed1b5704b8576159b54cee96ff1fd67c429a4e5f3&',
  'https://cdn.discordapp.com/attachments/1387874727598755873/1538564799254892595/m2-res_8p.mp4?ex=6ad783a1&is=6ad63221&hm=5481cbe5d78bd0d40eb4e56e94313a477cf27101fc03dc403073124b05cdd0fd&',
  'https://cdn.discordapp.com/attachments/1387874727598755873/1538564886240563250/Download2.mp4?ex=6ad783b6&is=6ad63236&hm=a94515caa91f7437ad858387fe5df41200904b831636fb3ec690f90540d9c5b9&',
  'https://cdn.discordapp.com/attachments/1387874727598755873/1538564886240563250/Download2.mp4?ex=6ad783b6&is=6ad63236&hm=a94515caa91f7437ad858387fe5df41200904b831636fb3ec690f90540d9c5b9&',
  'https://cdn.discordapp.com/attachments/1387874727598755873/1538565137856864266/Download1.mp4?ex=6ad783f2&is=6ad63272&hm=7126021bf89fe79f091b30d7ad9f59e5fa572aab4dd53a8fe93a1a957e23804e&',
  'https://cdn.discordapp.com/attachments/1238532037896568986/1558498436276424737/v67nsw7.webm?ex=6ad785c6&is=6ad63446&hm=bf9e7f9d5d67718cd7cf68c1230fa3901998d7171d457649f9b0c3fcd8121279&',
  'https://cdn.discordapp.com/attachments/1537833115668447337/1538307050113605702/MVdAtjNj.mp4?ex=6ad73c55&is=6ad5ead5&hm=5b4c2bd908a916991135c2d257f2d36fcfdad4cf0ed766260ebd01153687c8b6&',
  'https://cdn.discordapp.com/attachments/1238532037896568986/1558498436276424737/v67nsw7.webm?ex=6ad785c6&is=6ad63446&hm=bf9e7f9d5d67718cd7cf68c1230fa3901998d7171d457649f9b0c3fcd8121279&',
  'https://cdn.discordapp.com/attachments/1559464138348957776/1559466183353180211/v0kbnpr.mp4?ex=6ad7bf4f&is=6ad66dcf&hm=ca24882413fad5b194ad7bf2b786d2e601e9d8eeafc140c636d4bd8376b5f68a&',
  'https://cdn.discordapp.com/attachments/1451292870500814891/1559905251035848745/itstime1_1.webm?ex=6ad75df9&is=6ad60c79&hm=4a6bc2c0508795a2b80149e760698888c3808ebd698d68cdc5f9092e9bbf409b&',
  'https://cdn.discordapp.com/attachments/1537156891933806594/1551170651795103837/VID_20260903_071740_430.mp4?ex=6ab0ffbe&is=6aafae3e&hm=b89b3b8fc254a063a8011502fd962352ee12f6a91a4c2c280367f5e97ab3918b&',
  'https://cdn.discordapp.com/attachments/1538135995659329627/1538137675557638154/m2-res_854p.mp4?ex=6a8195d7&is=6a804457&hm=c3244bb3eb5a58244884e749b2f9318eb5091eb981a34e3b38780d407e2dab38&',
  'https://cdn.discordapp.com/attachments/1538135995659329627/1538137462579142676/ciyakciyak.mp4?ex=6a8195a4&is=6a804424&hm=ce55449e23782b23ca041d4cd2ee95f884f96957f0d58faf0627b24338d99654&',
  'https://cdn.discordapp.com/attachments/1538135995659329627/1538137955531497542/m2-res_360p.mp4?ex=6a819619&is=6a804499&hm=7d9138554be57b434e692301e3cb5de55d13cef721b66c7085880ebe1655ecb5&',
  'https://cdn.discordapp.com/attachments/1538135995659329627/1538136957589131334/rapidsave.com_tarafmz_brlli_edelim-q575guhi0fjh1.mp4?ex=6a81952b&is=6a8043ab&hm=c39b7685c93fe6aa34aec2bdebb7ad6e76eca0801a83bb019d1ccea6f1125d84&',
  'https://cdn.discordapp.com/attachments/1434623092025725039/1565670131005390908/a485c38f444003dc4e4337f2787a0674.mp4?ex=6af43fef&is=6af2ee6f&hm=5030dab83eea9cb8526e7682c57e8085c4ead1bef97cf0977d7be4d84feafd6a&',
  'https://cdn.discordapp.com/attachments/1284995887151583343/1569834087093510265/ssstik.io_1794347996039.mp4?ex=6af4e56c&is=6af393ec&hm=f7be97ceb79b515abf8dcc9e2ef6bcc9f3d4b2d05a807fd210b0f6e4f84820b1&',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('funnyvideo')
    .setDescription('sends a random video')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const video = VIDEOS[Math.floor(Math.random() * VIDEOS.length)];
    await interaction.reply(video);
  },
};