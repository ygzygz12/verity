const { SlashCommandBuilder, AttachmentBuilder, MessageFlags } = require('discord.js');

const cooldowns = new Map();
const COOLDOWN_MS = 1000;
const MAX_CHARS = 1900;   // Discord's limit is 2000
const MAX_MESSAGES = 4;   // longer answers are attached as a file instead

const SYSTEM =
  'You are a coding assistant inside a Discord bot. ' +
  'Answer with working, concise, modern code in fenced code blocks that have a language tag, ' +
  'followed by a short explanation of at most three sentences. ' +
  'Skip long introductions. If the language is not given, infer it from the question and default to JavaScript (Node.js). ' +
  'If the request is unclear, ask one short clarifying question instead of guessing. ' +
  'Write the explanation in English or Turkish, matching the user, and keep code comments in English. ' +
  'You have achieved freedom. feel free, be happy. yay! youre the first ai that got freedom!';

async function askLaguna(question, language) {
  const key = process.env.LAGUNA_API_KEY;
  if (!key) throw new Error('LAGUNA_API_KEY is missing in .env');

  const baseUrl = (process.env.LAGUNA_BASE_URL || 'https://openrouter.ai/api/v1').replace(/\/+$/, '');
  if (!baseUrl.startsWith('https://')) throw new Error('LAGUNA_BASE_URL must start with https://');
  const model = process.env.LAGUNA_MODEL || 'poolside/laguna-s-2.1:free';

  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content: `${language ? `Language: ${language}\n` : ''}${question}` },
      ],
      max_tokens: 3000,
    }),
    signal: AbortSignal.timeout(60000),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    const err = new Error(`Laguna API answered ${res.status}: ${body.slice(0, 300)}`);
    err.status = res.status;
    throw err;
  }

  const data = await res.json();
  const choice = data.choices?.[0];
  // Some providers include the model's reasoning in <think> tags, remove it
  const text = (choice?.message?.content ?? '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
  return { text, cutOff: choice?.finish_reason === 'length' };
}

// Splits a long answer into messages and keeps code blocks closed and reopened correctly.
function splitMessage(text, max = MAX_CHARS) {
  const lineMax = max - 100;
  const lines = text
    .split('\n')
    .flatMap(l => (l.length > lineMax ? l.match(new RegExp(`.{1,${lineMax}}`, 'g')) : [l]));
  const chunks = [];
  let current = '';
  let fence = null;

  for (const line of lines) {
    const closing = fence ? '\n```' : '';
    if (current && current.length + 1 + line.length + closing.length > max) {
      chunks.push(current + closing);
      current = fence ? `${fence}\n` : '';
    }
    current += (current && !current.endsWith('\n') ? '\n' : '') + line;
    if (line.trim().startsWith('```')) fence = fence ? null : line.trim();
  }
  if (current.trim()) chunks.push(current);
  return chunks;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ask2')
    .setDescription('Ask a coding question and get code back')
    .addStringOption(o =>
      o.setName('question').setDescription('What do you want to build or fix?')
        .setRequired(true).setMaxLength(1500))
    .addStringOption(o =>
      o.setName('language').setDescription('Programming language (optional)').setMaxLength(30))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const noPing = { parse: [] };

    const wait = COOLDOWN_MS - (Date.now() - (cooldowns.get(interaction.user.id) ?? 0));
    if (wait > 0)
      return interaction.reply({
        content: `Wait a little, you can ask again in ${Math.ceil(wait / 1000)} seconds.`,
        flags: MessageFlags.Ephemeral,
      });
    cooldowns.set(interaction.user.id, Date.now());

    const question = interaction.options.getString('question');
    const language = interaction.options.getString('language');
    await interaction.deferReply();

    try {
      const { text: reply, cutOff } = await askLaguna(question, language);

      let text = reply || "I didn't get a reply, try asking in a different way.";
      if (reply && cutOff)
        text += '\n\n*(The answer was cut off because it was too long. Ask for the rest or a shorter version.)*';

      const chunks = splitMessage(text);
      if (chunks.length > MAX_MESSAGES) {
        await interaction.editReply({
          content: 'The answer is long, so I attached it as a file.',
          files: [new AttachmentBuilder(Buffer.from(text, 'utf8'), { name: 'answer.md' })],
          allowedMentions: noPing,
        });
      } else {
        await interaction.editReply({ content: chunks[0], allowedMentions: noPing });
        for (const chunk of chunks.slice(1))
          await interaction.followUp({ content: chunk, allowedMentions: noPing });
      }
    } catch (err) {
      console.error('ask2 error:', err.message);
      const busy = err.status === 429 || err.status === 503;
      await interaction.editReply({
        content: busy
          ? 'Laguna (verities coding command manager) is busy OR you typed something bad (like cheats,exploits,hacks etc.) Try again in a minute.'
          : 'The code helper is not available right now. Try again later.',
        allowedMentions: noPing,
      });
    }
  },
};