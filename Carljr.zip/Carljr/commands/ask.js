const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { GoogleGenAI } = require('@google/genai');

let ai;
const cooldowns = new Map();
const COOLDOWN_MS = 15000;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ask')
    .setDescription('Ask Carl Jr. anything!')
    .addStringOption(o =>
      o.setName('question').setDescription('Your question').setRequired(true).setMaxLength(1000))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const last = cooldowns.get(interaction.user.id) ?? 0;
    const wait = COOLDOWN_MS - (Date.now() - last);
    if (wait > 0)
      return interaction.reply({
        content: `Wait a little, you can ask another question in ${Math.ceil(wait / 1000)} seconds.`,
        flags: MessageFlags.Ephemeral,
      });
    cooldowns.set(interaction.user.id, Date.now());

    await interaction.deferReply();
    try {
      ai ??= new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: interaction.options.getString('question'),
        config: {
          systemInstruction: 'You are Carl Jr.(Son of carl-bot) People will ask you questions. Keep them short becuase you break when u type too long.',
          maxOutputTokens: 600,
          thinkingConfig: { thinkingLevel: 'low' },
        },
      });
      await interaction.editReply((response.text || "I didn't get your question.").slice(0, 2000));
    } catch (err) {
      console.error(err);
      await interaction.editReply('Carl Jr. is not available right now. Try again later.');
    }
  },
};