const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { logAction } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Sets the slowmode of a channel')
    .addIntegerOption(o =>
      o.setName('seconds').setDescription('Seconds between messages (0 turns it off, max 21600)')
        .setMinValue(0).setMaxValue(21600).setRequired(true))
    .addChannelOption(o =>
      o.setName('channel').setDescription('Channel (default: current channel)')
        .addChannelTypes(ChannelType.GuildText))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const seconds = interaction.options.getInteger('seconds');
    const channel = interaction.options.getChannel('channel') ?? interaction.channel;

    if (!channel.permissionsFor(interaction.guild.members.me).has(PermissionFlagsBits.ManageChannels))
      return interaction.reply({ content: "I don't have permission to manage that channel.", flags: MessageFlags.Ephemeral });

    await channel.setRateLimitPerUser(seconds, `Slowmode set by ${interaction.user.tag}`);

    await logAction(interaction, {
      action: '⏱️ Slowmode',
      color: 0x5865f2,
      target: `${channel}`,
      details: seconds === 0 ? 'Turned off' : `${seconds} seconds`,
    });
    await interaction.reply(
      seconds === 0
        ? `⏱️ Slowmode turned off in ${channel}.`
        : `⏱️ Slowmode in ${channel} set to **${seconds}** seconds.`
    );
  },
};