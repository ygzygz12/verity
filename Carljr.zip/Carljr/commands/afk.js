const { SlashCommandBuilder } = require('discord.js');
const { setAfk } = require('../utils/afk');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Sets you as AFK. I will tell people who mention you.')
    .addStringOption(o =>
      o.setName('reason').setDescription('Why are you AFK?').setMaxLength(100))
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const reason = interaction.options.getString('reason') ?? 'AFK';
    setAfk(interaction.user.id, reason);
    await interaction.reply({
      content: `💤 **${interaction.user.username}** is now AFK: ${reason}`,
      allowedMentions: { parse: [] },
    });
  },
};