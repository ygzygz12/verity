const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nick')
    .setDescription("Changes or resets a member's nickname")
    .addUserOption(o => o.setName('user').setDescription('Member').setRequired(true))
    .addStringOption(o =>
      o.setName('nickname').setDescription('New nickname (leave empty to reset)').setMaxLength(32))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const nickname = interaction.options.getString('nickname');
    const ephemeral = MessageFlags.Ephemeral;

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member)
      return interaction.reply({ content: 'That user is not in this server.', flags: ephemeral });

    const isOwner = interaction.guild.ownerId === interaction.user.id;
    if (!isOwner && user.id !== interaction.user.id &&
        interaction.member.roles.highest.position <= member.roles.highest.position)
      return interaction.reply({ content: "You can't change the nickname of someone with an equal or higher role.", flags: ephemeral });
    if (!member.manageable)
      return interaction.reply({ content: "I can't change that member's nickname (their role is higher than mine, or they own the server).", flags: ephemeral });

    await member.setNickname(nickname || null, `Changed by ${interaction.user.tag}`);

    await logAction(interaction, {
      action: '✏️ Nickname changed',
      color: 0x5865f2,
      target: fmtUser(user),
      details: nickname ? `New nickname: ${nickname}` : 'Nickname reset',
    });
    await interaction.reply(
      nickname
        ? `✏️ **${user.username}**'s nickname is now **${nickname}**.`
        : `✏️ **${user.username}**'s nickname was reset.`
    );
  },
};