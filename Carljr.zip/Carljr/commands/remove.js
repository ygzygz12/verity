const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Removes a track from the queue')
    .addIntegerOption(o =>
      o.setName('position').setDescription('Queue position (see /queue)').setMinValue(1).setRequired(true))
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });

    const position = interaction.options.getInteger('position');
    const removed = music.removeTrack(check.session, position);
    if (!removed)
      return interaction.reply({ content: `There is no track at position ${position}. Check \`/queue\`.`, flags: MessageFlags.Ephemeral });

    await interaction.reply({ content: `🗑️ Removed **${removed.title}** from the queue.`, allowedMentions: { parse: [] } });
  },
};