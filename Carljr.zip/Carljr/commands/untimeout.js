const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Kullanıcının susturmasını kaldırır')
    .addUserOption(o => o.setName('kullanici').setDescription('Kullanıcı').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member)
      return interaction.reply({ content: 'Bu kullanıcı sunucuda değil.', flags: MessageFlags.Ephemeral });

    await member.timeout(null);
    await logAction(interaction, { action: '🔊 Timeout removed', color: 0x57f287, target: fmtUser(user) });
    await interaction.reply(`🔊 **${user.tag}** kullanıcısının susturması kaldırıldı.`);
  },
};