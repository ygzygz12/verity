const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');

const OWNER_ID = '1385961376656134257';
const COOLDOWN_MS = 60000;
const cooldowns = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggestion')
    .setDescription('Send a suggestion to the developer')
    .addStringOption(o =>
      o.setName('text').setDescription('What would you like to suggest?').setRequired(true).setMaxLength(1000))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;

    if (!process.env.SUGGESTION_WEBHOOK_URL)
      return interaction.reply({ content: 'Suggestions are not set up right now.', flags: ephemeral });

    const last = cooldowns.get(interaction.user.id) ?? 0;
    const wait = COOLDOWN_MS - (Date.now() - last);
    if (wait > 0)
      return interaction.reply({
        content: `Please wait ${Math.ceil(wait / 1000)} seconds before sending another suggestion.`,
        flags: ephemeral,
      });

    const text = interaction.options.getString('text');
    await interaction.deferReply({ flags: ephemeral });

    try {
      const res = await fetch(process.env.SUGGESTION_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: 'Suggestions',
          content: `<@${OWNER_ID}> new suggestion!`,
          allowed_mentions: { users: [OWNER_ID] },
          embeds: [{
            color: 0x5865f2,
            title: 'New Suggestion',
            description: text,
            fields: [
              { name: 'From', value: `${interaction.user.tag} (${interaction.user.id})` },
              { name: 'Server', value: interaction.guild?.name ?? 'DM / User install' },
            ],
            timestamp: new Date().toISOString(),
          }],
        }),
      });

      if (!res.ok) throw new Error(`Webhook responded with ${res.status}`);

      cooldowns.set(interaction.user.id, Date.now());
      await interaction.editReply('Thanks! Your suggestion was sent.');
    } catch (err) {
      console.error(err);
      await interaction.editReply('Could not send your suggestion right now. Try again later.');
    }
  },
};