const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

const VERIFICATION = ['None', 'Low', 'Medium', 'High', 'Very high'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Shows information about this server')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const guild = interaction.guild;
    const owner = await guild.fetchOwner().catch(() => null);
    const created = Math.floor(guild.createdTimestamp / 1000);

    const channels = guild.channels.cache;
    const text = channels.filter(c => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement).size;
    const voice = channels.filter(c => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice).size;
    const categories = channels.filter(c => c.type === ChannelType.GuildCategory).size;

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ size: 512 }))
      .addFields(
        { name: 'Owner', value: owner ? `${owner.user.username}` : 'Unknown', inline: true },
        { name: 'Members', value: `${guild.memberCount.toLocaleString('en-US')}`, inline: true },
        { name: 'Created', value: `<t:${created}:D> (<t:${created}:R>)` },
        { name: 'Channels', value: `${text} text, ${voice} voice, ${categories} categories`, inline: true },
        { name: 'Roles', value: `${guild.roles.cache.size - 1}`, inline: true },
        { name: 'Emojis', value: `${guild.emojis.cache.size}`, inline: true },
        { name: 'Boosts', value: `${guild.premiumSubscriptionCount ?? 0} (tier ${guild.premiumTier})`, inline: true },
        { name: 'Verification', value: VERIFICATION[guild.verificationLevel] ?? 'Unknown', inline: true },
      )
      .setFooter({ text: `ID: ${guild.id}` });

    if (guild.description) embed.setDescription(guild.description);
    if (guild.bannerURL()) embed.setImage(guild.bannerURL({ size: 1024 }));

    await interaction.reply({ embeds: [embed] });
  },
};