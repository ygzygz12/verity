const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { parseDuration, addReminder, getUserReminders, removeReminder } = require('../utils/reminders');

const MIN_MS = 10 * 1000;
const MAX_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_PER_USER = 10;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Set and manage reminders')
    .addSubcommand(s =>
      s.setName('add').setDescription('Create a reminder')
        .addStringOption(o =>
          o.setName('time').setDescription('When? Examples: 10m, 2h, 1d, 1h30m').setRequired(true))
        .addStringOption(o =>
          o.setName('message').setDescription('What should I remind you about?').setRequired(true).setMaxLength(500)))
    .addSubcommand(s => s.setName('list').setDescription('Show your reminders'))
    .addSubcommand(s =>
      s.setName('cancel').setDescription('Cancel a reminder')
        .addIntegerOption(o =>
          o.setName('id').setDescription('Reminder number (see /remind list)').setMinValue(1).setRequired(true)))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const ms = parseDuration(interaction.options.getString('time'));
      if (!ms)
        return interaction.reply({ content: 'Invalid time. Use things like `10m`, `2h`, `1d` or `1h30m`.', flags: ephemeral });
      if (ms < MIN_MS || ms > MAX_MS)
        return interaction.reply({ content: 'Time must be between 10 seconds and 30 days.', flags: ephemeral });
      if (getUserReminders(interaction.user.id).length >= MAX_PER_USER)
        return interaction.reply({ content: `You can have at most ${MAX_PER_USER} reminders. Cancel one first.`, flags: ephemeral });

      const time = Date.now() + ms;
      const id = addReminder({
        userId: interaction.user.id,
        channelId: interaction.channelId,
        text: interaction.options.getString('message'),
        time,
      });
      return interaction.reply({
        content: `Reminder **#${id}** set. I'll remind you <t:${Math.floor(time / 1000)}:R> (<t:${Math.floor(time / 1000)}:f>).`,
        flags: ephemeral,
      });
    }

    if (sub === 'list') {
      const list = getUserReminders(interaction.user.id);
      if (!list.length)
        return interaction.reply({ content: "You don't have any reminders.", flags: ephemeral });
      const lines = list.map(r => `**#${r.id}** - <t:${Math.floor(r.time / 1000)}:R> - ${r.text.slice(0, 100)}`);
      return interaction.reply({ content: lines.join('\n'), flags: ephemeral });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getInteger('id');
      const ok = removeReminder(interaction.user.id, id);
      return interaction.reply({
        content: ok ? `Reminder #${id} cancelled.` : `You don't have a reminder #${id}.`,
        flags: ephemeral,
      });
    }
  },
};