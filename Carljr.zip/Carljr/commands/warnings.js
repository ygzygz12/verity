const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getWarns } = require('../utils/warns');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Bir kullanıcının uyarılarını listeler')
    .addUserOption(o => o.setName('kullanici').setDescription('Kullanıcı').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const warns = getWarns(interaction.guild.id, user.id);

    if (!warns.length)
      return interaction.reply(`**${user.tag}** kullanıcısının hiç uyarısı yok.`);

    const lines = warns.slice(-10).map(w =>
      `**#${w.id}** • <t:${Math.floor(w.date / 1000)}:f> • <@${w.moderatorId}>\n${w.reason}`
    );

    const embed = new EmbedBuilder()
      .setColor(0xffa500)
      .setTitle(`⚠️ ${user.tag} uyarıları (${warns.length})`)
      .setDescription(lines.join('\n\n'))
      .setFooter({ text: warns.length > 10 ? 'Son 10 uyarı gösteriliyor' : 'Tüm uyarılar' });

    await interaction.reply({ embeds: [embed] });
  },
};