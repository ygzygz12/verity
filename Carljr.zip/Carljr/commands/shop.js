const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, BANK_UPGRADE_MAX, getAccount } = require('../utils/economy');
const { ITEMS } = require('../utils/shop');

const fmt = n => n.toLocaleString('en-US');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Shows what you can buy with your coins')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const account = getAccount(interaction.user.id);

    const fields = Object.entries(ITEMS).map(([key, item]) => {
      let text = item.description;
      if (key === 'bank_upgrade') {
        const maxed = account.upgrades >= BANK_UPGRADE_MAX;
        text += `\nYou own **${account.upgrades}/${BANK_UPGRADE_MAX}**${maxed ? ' (maxed)' : ''}. Your bank limit: **${fmt(account.limit)}**.`;
      }
      return { name: `${item.emoji} ${item.name} - ${fmt(item.price)} ${CURRENCY.name}`, value: text };
    });

    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('Shop')
      .addFields(fields)
      .setFooter({ text: `Buy with /buy | Your wallet: ${fmt(account.balance)} ${CURRENCY.name}` });

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};