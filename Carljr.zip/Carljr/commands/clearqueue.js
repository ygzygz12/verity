const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearqueue')
    .setDescription('Clears the queue but keeps the current track playing')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });

    const count = music.clearQueue(check.session);
    if (!count)
      return interaction.reply({ content: 'The queue is already empty.', flags: MessageFlags.Ephemeral });
    await interaction.reply(`🧹 Cleared ${count} tracks from the queue.`);
  },
};