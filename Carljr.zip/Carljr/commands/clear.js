const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Kanaldaki mesajları siler')
    .addIntegerOption(o =>
      o.setName('adet').setDescription('Silinecek mesaj sayısı (1-100)')
        .setMinValue(1).setMaxValue(100).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const amount = interaction.options.getInteger('adet');
    const deleted = await interaction.channel.bulkDelete(amount, true);
    await logAction(interaction, {
      action: '🧹 Messages cleared',
      color: 0x5865f2,
      target: `${interaction.channel}`,
      details: `${deleted.size} messages deleted`,
    });
    await interaction.reply({
      content: `🧹 ${deleted.size} mesaj silindi.`,
      flags: MessageFlags.Ephemeral,
    });
  },
};