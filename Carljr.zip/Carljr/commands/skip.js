const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Skips the current track')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: ephemeral });

    const session = check.session;
    if (!session.current)
      return interaction.reply({ content: 'Nothing is playing.', flags: ephemeral });
    if (session.opening)
      return interaction.reply({ content: 'The track is still loading, try again in a moment.', flags: ephemeral });

    music.skip(session);
    await interaction.reply('⏭️ Skipped.');
  },
};