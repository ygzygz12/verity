const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { setLogChannel } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlog')
    .setDescription('Sets the mod-log channel (leave empty to turn logging off)')
    .addChannelOption(o =>
      o.setName('channel').setDescription('Where moderation logs are sent')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const ephemeral = MessageFlags.Ephemeral;

    if (!channel) {
      setLogChannel(interaction.guild.id, null);
      return interaction.reply({ content: 'Mod-log turned off.', flags: ephemeral });
    }

    const perms = channel.permissionsFor(interaction.guild.members.me);
    if (!perms?.has(['ViewChannel', 'SendMessages', 'EmbedLinks']))
      return interaction.reply({
        content: `I need **View Channel**, **Send Messages** and **Embed Links** in ${channel}.`,
        flags: ephemeral,
      });

    setLogChannel(interaction.guild.id, channel.id);
    await channel.send(`This channel is now the mod-log. Set by ${interaction.user.tag}.`);
    await interaction.reply({ content: `Mod-log channel set to ${channel}.`, flags: ephemeral });
  },
};