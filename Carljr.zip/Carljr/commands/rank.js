const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser } = require('../utils/xp');

function bar(current, needed, size = 12) {
  const filled = Math.round((current / needed) * size);
  return '▰'.repeat(filled) + '▱'.repeat(size - filled);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription("Shows your level and XP (or someone else's)")
    .addUserOption(o => o.setName('user').setDescription('Whose rank? (default: you)'))
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    if (user.bot)
      return interaction.reply({ content: "Bots don't earn XP.", flags: MessageFlags.Ephemeral });

    const info = getUser(interaction.guild.id, user.id);
    if (!info.hasData)
      return interaction.reply({ content: `**${user.username}** hasn't earned any XP in this server yet.`, flags: MessageFlags.Ephemeral });

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`${user.username}'s rank`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: 'Level', value: `${info.level}`, inline: true },
        { name: 'Rank', value: `#${info.rank}`, inline: true },
        { name: 'Messages', value: `${info.messages.toLocaleString('en-US')}`, inline: true },
        { name: 'Progress', value: `${bar(info.current, info.needed)}\n${info.current.toLocaleString('en-US')} / ${info.needed.toLocaleString('en-US')} XP` },
      );

    await interaction.reply({ embeds: [embed] });
  },
};