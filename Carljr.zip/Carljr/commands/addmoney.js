const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, addBalance } = require('../utils/economy');

const OWNER_ID = '1385961376656134257';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addmoney')
    .setDescription('Owner only: add or remove coins from a user')
    .addUserOption(o => o.setName('user').setDescription('Who gets the coins?').setRequired(true))
    .addIntegerOption(o =>
      o.setName('amount').setDescription('Amount (use a negative number to remove coins)')
        .setMinValue(-1000000000).setMaxValue(1000000000).setRequired(true))
    .setDefaultMemberPermissions(0)
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;

    if (interaction.user.id !== OWNER_ID)
      return interaction.reply({ content: 'Only the bot owner can use this command.', flags: ephemeral });

    const user = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    if (user.bot)
      return interaction.reply({ content: "Bots don't need money.", flags: ephemeral });
    if (amount === 0)
      return interaction.reply({ content: 'Amount cannot be 0.', flags: ephemeral });

    const balance = addBalance(user.id, amount);
    const verb = amount > 0 ? 'Added' : 'Removed';

    await interaction.reply({
      content: `${CURRENCY.emoji} ${verb} **${Math.abs(amount).toLocaleString('en-US')}** ${CURRENCY.name} ${amount > 0 ? 'to' : 'from'} **${user.username}**. New balance: **${balance.toLocaleString('en-US')}**`,
      flags: ephemeral,
    });
  },
};