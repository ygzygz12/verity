const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { CURRENCY, getAccount } = require('../utils/economy');

const fmt = n => n.toLocaleString('en-US');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription("Shows your balance (or someone else's)")
    .addUserOption(o => o.setName('user').setDescription('Whose balance?'))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const target = interaction.options.getUser('user') ?? interaction.user;
    const { balance, bank, limit } = getAccount(target.id);
    const limitText = Number.isFinite(limit) ? ` / ${fmt(limit)}` : '';

    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle(`${CURRENCY.emoji} ${target.username}'s balance`)
      .addFields(
        { name: 'Wallet', value: `${fmt(balance)} ${CURRENCY.name}`, inline: true },
        { name: 'Bank', value: `${fmt(bank)}${limitText}`, inline: true },
        { name: 'Total', value: `${fmt(balance + bank)} ${CURRENCY.name}`, inline: true },
      );

    await interaction.reply({ embeds: [embed] });
  },
};