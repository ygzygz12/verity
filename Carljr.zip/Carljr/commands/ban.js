const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bir kullanıcıyı sunucudan banlar')
    .addUserOption(o => o.setName('kullanici').setDescription('Banlanacak kullanıcı').setRequired(true))
    .addStringOption(o => o.setName('sebep').setDescription('Ban sebebi'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const reason = interaction.options.getString('sebep') ?? 'Sebep belirtilmedi';
    const ephemeral = MessageFlags.Ephemeral;

    if (user.id === interaction.user.id)
      return interaction.reply({ content: 'Kendini banlayamazsın.', flags: ephemeral });

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (member) {
      const isOwner = interaction.guild.ownerId === interaction.user.id;
      if (!isOwner && interaction.member.roles.highest.position <= member.roles.highest.position)
        return interaction.reply({ content: 'Rolü senden yüksek veya eşit birini banlayamazsın.', flags: ephemeral });
      if (!member.bannable)
        return interaction.reply({ content: 'Bu kullanıcıyı banlayamıyorum (rolü benden yüksek olabilir).', flags: ephemeral });
    }

    await interaction.guild.members.ban(user, { reason: `${interaction.user.tag}: ${reason}` });
    await logAction(interaction, { action: '🔨 Ban', color: 0xed4245, target: fmtUser(user), reason });
    await interaction.reply(`🔨 **${user.tag}** banlandı. Sebep: ${reason}`);
  },
};