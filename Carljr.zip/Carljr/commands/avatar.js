const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription("Shows a user's avatar")
    .addUserOption(o => o.setName('user').setDescription('Whose avatar? (default: you)'))
    .addBooleanOption(o =>
      o.setName('server').setDescription('Show their server avatar instead, if they have one'))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const user = interaction.options.getUser('user') ?? interaction.user;
    const wantServer = interaction.options.getBoolean('server') ?? false;
    const member = interaction.options.getMember('user') ?? (user.id === interaction.user.id ? interaction.member : null);

    let source = user;
    let label = 'Avatar';
    if (wantServer && member?.avatar) {
      source = member;
      label = 'Server avatar';
    }

    const url = source.displayAvatarURL({ size: 1024 });
    const animated = url.includes('.gif');

    const links = [
      `[PNG](${source.displayAvatarURL({ extension: 'png', size: 4096, forceStatic: true })})`,
      `[JPG](${source.displayAvatarURL({ extension: 'jpg', size: 4096, forceStatic: true })})`,
      `[WEBP](${source.displayAvatarURL({ extension: 'webp', size: 4096, forceStatic: true })})`,
    ];
    if (animated) links.push(`[GIF](${source.displayAvatarURL({ extension: 'gif', size: 4096 })})`);

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`${user.username} - ${label}`)
      .setDescription(links.join(' • '))
      .setImage(url);

    if (wantServer && source === user)
      embed.setFooter({ text: 'No server avatar found, showing the global one.' });

    await interaction.reply({ embeds: [embed] });
  },
};