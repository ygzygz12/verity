const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

const IDLE_LEAVE_MS = 5 * 60 * 1000;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('join')
    .setDescription('Makes me join your voice channel')
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;

    const check = music.checkUser(interaction);
    if (check.error) return interaction.reply({ content: check.error, flags: ephemeral });
    if (check.session)
      return interaction.reply({ content: `I'm already in ${check.channel}.`, flags: ephemeral });
    if (!check.channel.joinable || !check.channel.speakable)
      return interaction.reply({ content: "I don't have permission to join and speak in that voice channel.", flags: ephemeral });

    await interaction.deferReply();
    try {
      const session = await music.createSession(interaction, check.channel);

      // Leave after 5 minutes if nothing gets played (a track starting cancels this timer)
      if (!session.current && !session.idleTimer) {
        session.idleTimer = setTimeout(() => {
          session.textChannel
            ?.send({ content: '👋 Nothing to play, leaving the voice channel.', allowedMentions: { parse: [] } })
            .catch(() => {});
          music.destroySession(session.guildId);
        }, IDLE_LEAVE_MS);
      }

      await interaction.editReply(`🔊 Joined ${check.channel}. Use \`/play\` to start the music.`);
    } catch (err) {
      console.error('Join error:', err.message);
      await interaction.editReply(`⚠️ ${err.user ? err.message : 'I could not join the voice channel.'}`);
    }
  },
};