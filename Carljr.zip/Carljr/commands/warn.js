const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { addWarn } = require('../utils/warns');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Bir kullanıcıyı uyarır')
    .addUserOption(o => o.setName('kullanici').setDescription('Uyarılacak kullanıcı').setRequired(true))
    .addStringOption(o => o.setName('sebep').setDescription('Uyarı sebebi').setRequired(true).setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const reason = interaction.options.getString('sebep');
    const ephemeral = MessageFlags.Ephemeral;

    if (user.bot)
      return interaction.reply({ content: 'Botları uyaramazsın.', flags: ephemeral });
    if (user.id === interaction.user.id)
      return interaction.reply({ content: 'Kendini uyaramazsın.', flags: ephemeral });

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member)
      return interaction.reply({ content: 'Bu kullanıcı sunucuda değil.', flags: ephemeral });

    const isOwner = interaction.guild.ownerId === interaction.user.id;
    if (!isOwner && interaction.member.roles.highest.position <= member.roles.highest.position)
      return interaction.reply({ content: 'Rolü senden yüksek veya eşit birini uyaramazsın.', flags: ephemeral });

    const { id, total } = addWarn(interaction.guild.id, user.id, interaction.user.id, reason);
    await logAction(interaction, {
      action: '⚠️ Warn',
      color: 0xffa500,
      target: fmtUser(user),
      reason,
      details: `Warn #${id}, total: ${total}`,
    });

    let dmInfo = '';
    try {
      await user.send(`⚠️ **${interaction.guild.name}** sunucusunda uyarıldın.\n**Sebep:** ${reason}\n**Toplam uyarın:** ${total}`);
    } catch {
      dmInfo = '\n*(Kullanıcının DM\'leri kapalı, mesaj gönderilemedi.)*';
    }

    await interaction.reply(`⚠️ **${user.tag}** uyarıldı. (Uyarı #${id}, toplam: ${total})\n**Sebep:** ${reason}${dmInfo}`);
  },
};