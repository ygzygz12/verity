const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, deposit } = require('../utils/economy');

const fmt = n => n.toLocaleString('en-US');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deposit')
    .setDescription('Move coins from your wallet to the bank (robbers cannot touch the bank)')
    .addStringOption(o =>
      o.setName('amount').setDescription("A number, or 'all'").setRequired(true).setMaxLength(20))
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const ephemeral = MessageFlags.Ephemeral;
    const raw = interaction.options.getString('amount').trim().toLowerCase();

    let amount = null;
    if (raw !== 'all' && raw !== 'max') {
      const clean = raw.replace(/[,_\s]/g, '');
      if (!/^\d{1,12}$/.test(clean) || Number(clean) < 1)
        return interaction.reply({ content: "Enter a positive number or `all`.", flags: ephemeral });
      amount = Number(clean);
    }

    const res = deposit(interaction.user.id, amount);
    switch (res.status) {
      case 'empty':
        return interaction.reply({ content: `You have no ${CURRENCY.name} in your wallet.`, flags: ephemeral });
      case 'full':
        return interaction.reply({
          content: `Your bank is full (limit: ${fmt(res.limit)} ${CURRENCY.name}). You can raise it with a Bank Upgrade in the \`/shop\`.`,
          flags: ephemeral,
        });
      case 'not_enough':
        return interaction.reply({ content: `You only have **${fmt(res.balance)}** ${CURRENCY.name} in your wallet.`, flags: ephemeral });
      case 'ok': {
        const note = res.capped ? ` (bank limit reached: ${fmt(res.limit)})` : '';
        return interaction.reply({
          content: `🏦 Deposited **${fmt(res.moved)}** ${CURRENCY.name}${note}.\nWallet: **${fmt(res.balance)}** | Bank: **${fmt(res.bank)}**`,
          flags: ephemeral,
        });
      }
    }
  },
};