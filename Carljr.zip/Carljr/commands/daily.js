const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, claim } = require('../utils/economy');

const REWARD = 500;
const COOLDOWN = 24 * 60 * 60 * 1000;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily reward')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const res = claim(interaction.user.id, 'daily', COOLDOWN, REWARD);
    if (!res.ok) {
      const when = Math.floor((Date.now() + res.remaining) / 1000);
      return interaction.reply({ content: `You already claimed your daily. Come back <t:${when}:R>.`, flags: MessageFlags.Ephemeral });
    }
    await interaction.reply(`${CURRENCY.emoji} You claimed **${REWARD}** ${CURRENCY.name}! Balance: **${res.balance.toLocaleString('en-US')}**`);
  },
};