const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const music = require('../utils/music');

const TEXT = {
  off: '➡️ Loop turned off.',
  track: '🔂 Looping the current track. Use `/skip` to move on.',
  queue: '🔁 Looping the whole queue.',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Sets the loop mode')
    .addStringOption(o =>
      o.setName('mode').setDescription('What should repeat?').setRequired(true)
        .addChoices(
          { name: 'Off', value: 'off' },
          { name: 'Current track', value: 'track' },
          { name: 'Whole queue', value: 'queue' },
        ))
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const check = music.checkUser(interaction, { needSession: true });
    if (check.error) return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });

    const mode = interaction.options.getString('mode');
    music.setLoop(check.session, mode);
    await interaction.reply(TEXT[mode]);
  },
};