const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { removeWarn } = require('../utils/warns');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('delwarn')
    .setDescription('Bir kullanıcının tek bir uyarısını siler')
    .addUserOption(o => o.setName('kullanici').setDescription('Kullanıcı').setRequired(true))
    .addIntegerOption(o => o.setName('id').setDescription('Silinecek uyarı numarası').setMinValue(1).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const id = interaction.options.getInteger('id');

    const ok = removeWarn(interaction.guild.id, user.id, id);
    if (!ok)
      return interaction.reply({ content: `**${user.tag}** için #${id} numaralı uyarı bulunamadı.`, flags: MessageFlags.Ephemeral });

    await logAction(interaction, { action: '🗑️ Warn deleted', color: 0x57f287, target: fmtUser(user), details: `Warn #${id}` });
    await interaction.reply(`✅ **${user.tag}** kullanıcısının #${id} numaralı uyarısı silindi.`);
  },
};