const { logAction, fmtUser } = require('../utils/modlog');
const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { CURRENCY, claim } = require('../utils/economy');

const COOLDOWN = 60 * 60 * 1000;
const JOBS = [
  'delivered pizzas',
  'walked some dogs',
  'fixed a neighbor\'s PC',
  'sold lemonade',
  'streamed to three viewers',
  'moderated a Discord server',
  'Glazed lloyd and Darker'
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('work')
    .setDescription('Work a shift to earn some coins')
    .setIntegrationTypes(0, 1)
    .setContexts(0, 1, 2),
  async execute(interaction) {
    const reward = 50 + Math.floor(Math.random() * 151);
    const res = claim(interaction.user.id, 'work', COOLDOWN, reward);
    if (!res.ok) {
      const when = Math.floor((Date.now() + res.remaining) / 1000);
      return interaction.reply({ content: `You're tired. You can work again <t:${when}:R>.`, flags: MessageFlags.Ephemeral });
    }
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];
    await interaction.reply(`You ${job} and earned **${reward}** ${CURRENCY.name}! Balance: **${res.balance.toLocaleString('en-US')}**`);
  },
};