const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { logAction, fmtUser } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Bir kullanıcıyı sunucudan atar')
    .addUserOption(o => o.setName('kullanici').setDescription('Atılacak kullanıcı').setRequired(true))
    .addStringOption(o => o.setName('sebep').setDescription('Atılma sebebi'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const user = interaction.options.getUser('kullanici');
    const reason = interaction.options.getString('sebep') ?? 'Sebep belirtilmedi';
    const ephemeral = MessageFlags.Ephemeral;

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member)
      return interaction.reply({ content: 'Bu kullanıcı sunucuda değil.', flags: ephemeral });
    if (user.id === interaction.user.id)
      return interaction.reply({ content: 'Kendini atamazsın.', flags: ephemeral });

    const isOwner = interaction.guild.ownerId === interaction.user.id;
    if (!isOwner && interaction.member.roles.highest.position <= member.roles.highest.position)
      return interaction.reply({ content: 'Rolü senden yüksek veya eşit birini atamazsın.', flags: ephemeral });
    if (!member.kickable)
      return interaction.reply({ content: 'Bu kullanıcıyı atamıyorum (rolü benden yüksek olabilir).', flags: ephemeral });

    await member.kick(`${interaction.user.tag}: ${reason}`);
    await logAction(interaction, { action: '👢 Kick', color: 0xed4245, target: fmtUser(user), reason });
    await interaction.reply(`👢 **${user.tag}** sunucudan atıldı. Sebep: ${reason}`);
  },
};