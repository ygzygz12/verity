const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js');
const { logAction } = require('../utils/modlog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlocks a previously locked channel')
    .addChannelOption(o =>
      o.setName('channel').setDescription('Channel to unlock (default: current channel)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .setIntegrationTypes(0)
    .setContexts(0),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') ?? interaction.channel;
    const everyone = interaction.guild.roles.everyone;

    if (!channel.permissionsFor(interaction.guild.members.me).has(PermissionFlagsBits.ManageChannels))
      return interaction.reply({ content: "I don't have permission to manage that channel.", flags: MessageFlags.Ephemeral });

    if (!channel.permissionOverwrites.cache.get(everyone.id)?.deny.has(PermissionFlagsBits.SendMessages))
      return interaction.reply({ content: `${channel} is not locked.`, flags: MessageFlags.Ephemeral });

    await channel.permissionOverwrites.edit(everyone, {
      SendMessages: null,
      SendMessagesInThreads: null,
      CreatePublicThreads: null,
      CreatePrivateThreads: null,
    }, { reason: `Unlocked by ${interaction.user.tag}` });

    await logAction(interaction, { action: '🔓 Channel unlocked', color: 0x57f287, target: `${channel}` });
    await interaction.reply(`🔓 ${channel} has been unlocked.`);
  },
};