require('dotenv').config();
const { Client, GatewayIntentBits, Collection, MessageFlags, PermissionFlagsBits, REST, Routes, ActivityType } = require('discord.js');
const fs = require('fs');
const { startReminders } = require('./utils/reminders');
const { getAfk, removeAfk } = require('./utils/afk');
const { addXp } = require('./utils/xp');
const { addBalance } = require('./utils/economy');
const { onVoiceUpdate } = require('./utils/music');

const LEVEL_UP_COIN_PER_LEVEL = 50;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
  ],
});
client.commands = new Collection();

for (const file of fs.readdirSync('./commands').filter(f => f.endsWith('.js'))) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

client.once('clientReady', async () => {
  console.log(`${client.user.tag} hazır! (Node ${process.version})`);

  // Rotate bot's thoughts every 3 seconds
  let toggle = false;
  const updateStatus = () => {
    const statusText = toggle
      ? 'Made By:LarpySeal'
      : `In ${client.guilds.cache.size} Servers!`;

    client.user.setPresence({
      activities: [{
        name: statusText,
        type: ActivityType.Custom,
      }],
      status: 'online',
    });

    toggle = !toggle;
  };
  updateStatus();
  setInterval(updateStatus, 8000);

  try {
    console.log(require('@discordjs/voice').generateDependencyReport());
  } catch (err) {
    console.error('Voice dependency report failed:', err.message);
  }
  startReminders(client);
  try {
    const body = [...client.commands.values()].map(c => c.data.toJSON());
    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body });
    console.log(`${body.length} komut yüklendi!`);
  } catch (err) {
    console.error('Komutlar yüklenemedi:', err);
  }
});

client.on('interactionCreate', async interaction => {
  if (interaction.isAutocomplete()) {
    try {
      await client.commands.get(interaction.commandName)?.autocomplete?.(interaction);
    } catch (err) {
      console.error('Autocomplete error:', err.message);
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (!command) return;
  if (command.data.contexts?.length === 1 && command.data.contexts[0] === 0 && !interaction.guild)
    return interaction.reply({
      content: 'This command only works in servers where the bot is added.',
      flags: MessageFlags.Ephemeral,
    });
  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(err);
    const msg = { content: 'Bir hata oluştu!', flags: MessageFlags.Ephemeral };
    if (interaction.replied || interaction.deferred) await interaction.followUp(msg).catch(() => {});
    else await interaction.reply(msg).catch(() => {});
  }
});

// Leave the voice channel when everyone left
client.on('voiceStateUpdate', (oldState, newState) => {
  try {
    onVoiceUpdate(oldState, newState);
  } catch (err) {
    console.error('Voice update error:', err.message);
  }
});

// XP and levels
client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;
  try {
    const res = addXp(message.guild.id, message.author.id);
    if (!res?.leveledUp) return;

    const reward = res.level * LEVEL_UP_COIN_PER_LEVEL;
    addBalance(message.author.id, reward);

    const me = message.guild.members.me;
    if (!me || !message.channel.permissionsFor(me)?.has(PermissionFlagsBits.SendMessages)) return;
    await message.channel.send({
      content: `🎉 ${message.author} reached **level ${res.level}**! You earned **${reward}** coins.`,
      allowedMentions: { users: [message.author.id] },
    });
  } catch (err) {
    console.error('XP error:', err.message);
  }
});

// AFK
client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;
  try {
    const back = removeAfk(message.author.id);
    const me = message.guild.members.me;
    const canSend = me && message.channel.permissionsFor(me)?.has(PermissionFlagsBits.SendMessages);
    if (!canSend) return;

    const noPing = { parse: [], repliedUser: false };

    if (back) {
      const reply = await message.reply({
        content: `👋 Welcome back, ${message.author.username}! You were AFK since <t:${Math.floor(back.since / 1000)}:R>.`,
        allowedMentions: noPing,
      });
      setTimeout(() => reply.delete().catch(() => {}), 8000);
    }

    if (!message.mentions.users.size) return;
    const lines = [];
    for (const user of message.mentions.users.values()) {
      if (user.id === message.author.id) continue;
      const afk = getAfk(user.id);
      if (afk) lines.push(`💤 **${user.username}** is AFK (since <t:${Math.floor(afk.since / 1000)}:R>): ${afk.reason}`);
      if (lines.length >= 3) break;
    }
    if (lines.length) await message.reply({ content: lines.join('\n'), allowedMentions: noPing });
  } catch (err) {
    console.error('AFK error:', err.message);
  }
});

client.login(process.env.TOKEN);