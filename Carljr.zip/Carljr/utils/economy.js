const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'data', 'economy.json');
const CURRENCY = { name: 'coins', emoji: '🪙' };
const BANK_LIMIT = 10000;       // base bank limit, use Infinity for no limit
const BANK_UPGRADE_STEP = 5000; // extra limit per bank upgrade
const BANK_UPGRADE_MAX = 10;    // how many upgrades one user can buy

function load() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return {};
  }
}

function save(data) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function user(data, id) {
  data[id] ??= { balance: 0, bank: 0, daily: 0, work: 0 };
  data[id].bank ??= 0;
  return data[id];
}

function bankLimitOf(u) {
  return BANK_LIMIT + (u?.bankUpgrades ?? 0) * BANK_UPGRADE_STEP;
}

// Wallet balance (this is the money that can be robbed)
function getBalance(id) {
  return load()[id]?.balance ?? 0;
}

function getAccount(id) {
  const u = load()[id] ?? {};
  return {
    balance: u.balance ?? 0,
    bank: u.bank ?? 0,
    limit: bankLimitOf(u),
    upgrades: u.bankUpgrades ?? 0,
  };
}

function addBalance(id, amount) {
  const data = load();
  const u = user(data, id);
  u.balance = Math.max(0, u.balance + amount);
  save(data);
  return u.balance;
}

// Removes the amount only if the user has enough in the wallet. Returns true/false.
function tryRemove(id, amount) {
  const data = load();
  const u = user(data, id);
  if (u.balance < amount) return false;
  u.balance -= amount;
  save(data);
  return true;
}

function transfer(fromId, toId, amount) {
  const data = load();
  const from = user(data, fromId);
  if (from.balance < amount) return false;
  from.balance -= amount;
  user(data, toId).balance += amount;
  save(data);
  return true;
}

// Shop purchase. `check(u)` can refuse by returning a message, `apply(u)` changes the user
// after the price was paid and returns extra result fields. Everything happens in one step.
function purchase(id, price, check, apply) {
  const data = load();
  const u = user(data, id);
  const refusal = check?.(u);
  if (refusal) return { status: 'refused', reason: refusal };
  if (u.balance < price) return { status: 'poor', balance: u.balance };
  u.balance -= price;
  const result = apply(u);
  save(data);
  return { status: 'ok', balance: u.balance, ...result };
}

// amount: a number, or null for "everything that fits"
function deposit(id, amount) {
  const data = load();
  const u = user(data, id);
  const limit = bankLimitOf(u);
  const space = Math.max(0, limit - u.bank);

  if (u.balance <= 0) return { status: 'empty' };
  if (space <= 0) return { status: 'full', limit };

  const wanted = amount === null ? u.balance : amount;
  if (wanted > u.balance) return { status: 'not_enough', balance: u.balance };

  const moved = Math.min(wanted, space);
  u.balance -= moved;
  u.bank += moved;
  save(data);
  return { status: 'ok', moved, balance: u.balance, bank: u.bank, limit, capped: moved < wanted };
}

// amount: a number, or null for "everything in the bank"
function withdraw(id, amount) {
  const data = load();
  const u = user(data, id);

  if (u.bank <= 0) return { status: 'empty' };

  const wanted = amount === null ? u.bank : amount;
  if (wanted > u.bank) return { status: 'not_enough', bank: u.bank };

  u.bank -= wanted;
  u.balance += wanted;
  save(data);
  return { status: 'ok', moved: wanted, balance: u.balance, bank: u.bank };
}

// key: 'daily' or 'work'
function claim(id, key, cooldownMs, reward) {
  const data = load();
  const u = user(data, id);
  const remaining = cooldownMs - (Date.now() - (u[key] ?? 0));
  if (remaining > 0) return { ok: false, remaining };
  u[key] = Date.now();
  u.balance += reward;
  save(data);
  return { ok: true, balance: u.balance };
}

// Robbery. Only the victim's WALLET can be stolen, the bank is safe.
// Stealing is capped by the victim's wallet, maxSteal and the thief's own wallet.
// On failure the thief pays a fine to the victim, so no coins are created or destroyed.
function rob(thiefId, victimId, { cooldownMs, shieldMs, chance, minBalance, maxSteal, fineRatio }) {
  const data = load();
  const thief = user(data, thiefId);
  const victim = user(data, victimId);
  const now = Date.now();

  const cooldown = cooldownMs - (now - (thief.rob ?? 0));
  if (cooldown > 0) return { status: 'cooldown', remaining: cooldown };
  const shield = shieldMs - (now - (victim.robbedAt ?? 0));
  if (shield > 0) return { status: 'shield', remaining: shield };
  if (thief.balance < minBalance) return { status: 'thief_poor' };
  if (victim.balance < minBalance) return { status: 'victim_poor' };

  thief.rob = now;
  const share = Math.floor(victim.balance * (0.1 + Math.random() * 0.2));
  const attempt = Math.max(1, Math.min(share, maxSteal, thief.balance));

  if (Math.random() < chance) {
    victim.balance -= attempt;
    thief.balance += attempt;
    victim.robbedAt = now;
    save(data);
    return { status: 'success', amount: attempt, balance: thief.balance };
  }

  const fine = Math.min(thief.balance, Math.max(1, Math.round(attempt * fineRatio)));
  thief.balance -= fine;
  victim.balance += fine;
  save(data);
  return { status: 'fail', amount: fine, balance: thief.balance };
}

// Leaderboard uses wallet + bank
function top(limit = 10) {
  return Object.entries(load())
    .map(([id, u]) => ({ id, balance: (u.balance ?? 0) + (u.bank ?? 0) }))
    .filter(u => u.balance > 0)
    .sort((a, b) => b.balance - a.balance)
    .slice(0, limit);
}

module.exports = {
  CURRENCY, BANK_LIMIT, BANK_UPGRADE_STEP, BANK_UPGRADE_MAX, bankLimitOf,
  getBalance, getAccount, addBalance, tryRemove, transfer, purchase,
  deposit, withdraw, claim, rob, top,
};