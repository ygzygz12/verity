const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'data', 'reminders.json');
const CHECK_MS = 15000;

function load() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return [];
  }
}

function save(list) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(list, null, 2));
}

// "10m", "1h30m", "2d" -> milliseconds (null if invalid)
function parseDuration(input) {
  const str = input.toLowerCase().replace(/\s+/g, '');
  if (!/^(\d+[dhms])+$/.test(str)) return null;
  const units = { d: 86400000, h: 3600000, m: 60000, s: 1000 };
  let total = 0;
  for (const [, n, u] of str.matchAll(/(\d+)([dhms])/g)) total += Number(n) * units[u];
  return total;
}

function addReminder({ userId, channelId, text, time }) {
  const list = load();
  const id = list.length ? Math.max(...list.map(r => r.id)) + 1 : 1;
  list.push({ id, userId, channelId, text, time });
  save(list);
  return id;
}

function getUserReminders(userId) {
  return load().filter(r => r.userId === userId).sort((a, b) => a.time - b.time);
}

function removeReminder(userId, id) {
  const list = load();
  const index = list.findIndex(r => r.id === id && r.userId === userId);
  if (index === -1) return false;
  list.splice(index, 1);
  save(list);
  return true;
}

async function deliver(client, r, late) {
  const content = ` **Reminder${late ? ' (late, the bot was offline)' : ''}:** ${r.text}`;
  const user = await client.users.fetch(r.userId).catch(() => null);
  try {
    await user.send(content);
    return;
  } catch {
    // DMs closed, try the channel it was created in
  }
  const channel = r.channelId ? await client.channels.fetch(r.channelId).catch(() => null) : null;
  if (channel?.send) {
    await channel
      .send({ content: `<@${r.userId}> ${content}`, allowedMentions: { users: [r.userId] } })
      .catch(() => {});
  }
}

function startReminders(client) {
  setInterval(async () => {
    const now = Date.now();
    const list = load();
    const due = list.filter(r => r.time <= now);
    if (!due.length) return;
    save(list.filter(r => r.time > now));
    for (const r of due) {
      try {
        await deliver(client, r, now - r.time > 60000);
      } catch (err) {
        console.error('Reminder error:', err);
      }
    }
  }, CHECK_MS);
}

module.exports = { parseDuration, addReminder, getUserReminders, removeReminder, startReminders };