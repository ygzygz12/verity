const economy = require('./economy');

const BOX_PRICE = 500;
const UPGRADE_PRICE = 3000;

// weight = chance in percent (the weights add up to 100)
const BOX_TABLE = [
  { weight: 50, min: 100, max: 300 },
  { weight: 30, min: 301, max: 600 },
  { weight: 14, min: 601, max: 1000 },
  { weight: 5, min: 1001, max: 2000 },
  { weight: 1, min: 3000, max: 5000 },
];
const BOX_TEXT = ['A small find.', 'Not bad!', 'Nice haul!', 'Big win! 🎉', 'JACKPOT! 💎'];
const BOX_AVG = Math.round(
  BOX_TABLE.reduce((sum, t) => sum + (t.weight / 100) * ((t.min + t.max) / 2), 0)
);

function rollBox() {
  let roll = Math.random() * 100;
  for (let i = 0; i < BOX_TABLE.length; i++) {
    const t = BOX_TABLE[i];
    if (roll < t.weight || i === BOX_TABLE.length - 1)
      return { tier: i, reward: t.min + Math.floor(Math.random() * (t.max - t.min + 1)) };
    roll -= t.weight;
  }
}

const ITEMS = {
  mystery_box: {
    name: 'Mystery Box',
    emoji: '🎁',
    price: BOX_PRICE,
    description: `Opens right away for a random prize between ${BOX_TABLE[0].min} and ${BOX_TABLE.at(-1).max} coins. The average prize is about ${BOX_AVG}, so it's a gamble.`,
  },
  bank_upgrade: {
    name: 'Bank Upgrade',
    emoji: '🏦',
    price: UPGRADE_PRICE,
    description: `Raises your bank limit by ${economy.BANK_UPGRADE_STEP.toLocaleString('en-US')} coins. You can buy up to ${economy.BANK_UPGRADE_MAX} upgrades.`,
  },
};

function buyItem(userId, key) {
  if (key === 'mystery_box') {
    return economy.purchase(userId, BOX_PRICE, null, u => {
      const { tier, reward } = rollBox();
      u.balance += reward;
      return { reward, tier };
    });
  }

  if (key === 'bank_upgrade') {
    return economy.purchase(
      userId,
      UPGRADE_PRICE,
      u => ((u.bankUpgrades ?? 0) >= economy.BANK_UPGRADE_MAX
        ? `You already own the maximum of ${economy.BANK_UPGRADE_MAX} bank upgrades.`
        : null),
      u => {
        u.bankUpgrades = (u.bankUpgrades ?? 0) + 1;
        return { upgrades: u.bankUpgrades, limit: economy.bankLimitOf(u) };
      }
    );
  }

  return { status: 'refused', reason: 'That item does not exist.' };
}

module.exports = { ITEMS, BOX_TEXT, buyItem };