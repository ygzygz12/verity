const fs = require('fs');
const path = require('path');

function randomFile(folder) {
  const dir = path.join(__dirname, '..', 'media', folder);
  const files = fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => !f.startsWith('.')) : [];
  if (!files.length) return null;
  return path.join(dir, files[Math.floor(Math.random() * files.length)]);
}

module.exports = { randomFile };