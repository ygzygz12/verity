const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const BIN_DIR = path.join(__dirname, '..', 'bin');
const BIN = path.join(BIN_DIR, 'yt-dlp');
const CACHE_DIR = path.join(__dirname, '..', 'data', 'yt-cache');
const COOKIES = path.join(__dirname, '..', 'data', 'cookies.txt');
const MAX_DURATION_S = 3 * 60 * 60;
const HOSTS = new Set(['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be']);

const userError = msg => Object.assign(new Error(msg), { user: true });

function isYoutubeUrl(text) {
  try {
    const u = new URL(text);
    return (u.protocol === 'https:' || u.protocol === 'http:') && HOSTS.has(u.hostname.toLowerCase());
  } catch {
    return false;
  }
}

// ---------- Installing and updating yt-dlp ----------

function assetName() {
  if (process.platform !== 'linux') throw new Error(`Unsupported platform: ${process.platform}`);
  return process.arch === 'arm64' ? 'yt-dlp_linux_aarch64' : 'yt-dlp_linux';
}

async function download() {
  const res = await fetch(`https://github.com/yt-dlp/yt-dlp/releases/latest/download/${assetName()}`);
  if (!res.ok || !res.body) throw new Error(`Download failed with status ${res.status}`);
  fs.mkdirSync(BIN_DIR, { recursive: true });
  const tmp = `${BIN}.part`;
  await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(tmp));
  fs.chmodSync(tmp, 0o755);
  fs.renameSync(tmp, BIN);
}

function run(args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const proc = spawn(BIN, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let out = '';
    let err = '';
    const timer = setTimeout(() => proc.kill('SIGKILL'), timeoutMs);
    proc.stdout.on('data', d => { if (out.length < 5_000_000) out += d; });
    proc.stderr.on('data', d => { if (err.length < 20000) err += d; });
    proc.on('error', e => { clearTimeout(timer); reject(e); });
    proc.on('close', (code, signal) => { clearTimeout(timer); resolve({ code, signal, out, err }); });
  });
}

let ready = null;

async function prepare() {
  if (!fs.existsSync(BIN)) {
    try {
      await download();
      console.log('yt-dlp downloaded.');
    } catch (err) {
      console.error('yt-dlp download error:', err.message);
      throw userError('I could not download the YouTube tool (yt-dlp). The host may block downloads or writing files.');
    }
  }
  fs.mkdirSync(CACHE_DIR, { recursive: true });
  // Update once every time the bot starts, because YouTube breaks yt-dlp often.
  try {
    const r = await run(['-U'], 60000);
    const last = (r.out.trim() || r.err.trim()).split('\n').pop();
    console.log('yt-dlp update:', last);
  } catch (err) {
    console.error('yt-dlp update error:', err.message);
  }
}

function ensure() {
  ready ??= prepare().catch(err => {
    ready = null;
    throw err;
  });
  return ready;
}

// ---------- Helpers ----------

function baseArgs() {
  const args = [
    '--no-warnings', '--no-playlist', '--js-runtimes', 'node',
    '--socket-timeout', '20', '--cache-dir', CACHE_DIR,
  ];
  if (fs.existsSync(COOKIES)) args.push('--cookies', COOKIES);
  return args;
}

function explainSpawn(err) {
  console.error('yt-dlp spawn error:', err.message);
  return 'I cannot run the YouTube tool on this host (it may block running downloaded programs).';
}

function explain(stderr) {
  console.error('yt-dlp:', stderr.trim().split('\n').slice(-3).join(' | '));
  const s = stderr.toLowerCase();
  if (s.includes('not a bot') || s.includes('sign in to confirm'))
    return 'YouTube is blocking this server (it thinks it is a bot). This is common on hosting IPs. A cookies file can fix it.';
  if (s.includes('private video')) return 'That video is private.';
  if (s.includes('age') && s.includes('restricted')) return 'That video is age-restricted.';
  if (s.includes('unavailable') || s.includes('not available in your country')) return 'That video is not available.';
  if (s.includes('http error 429')) return 'YouTube is rate limiting me. Try again later.';
  if (s.includes('requested format') || s.includes('challenge') || s.includes('js runtime') || s.includes('signature'))
    return 'YouTube changed something and yt-dlp needs an update. Restart the bot, it updates itself on start.';
  return 'YouTube did not let me play that.';
}

// ---------- Public functions ----------

// Finds a video from a YouTube link or a search text.
async function getInfo(query) {
  await ensure();
  const isUrl = isYoutubeUrl(query);
  const target = isUrl ? query : `ytsearch1:${query}`;

  let res;
  try {
    res = await run([...baseArgs(), '--flat-playlist', '--dump-single-json', '--', target], 45000);
  } catch (err) {
    throw userError(explainSpawn(err));
  }
  if (res.code !== 0 || !res.out.trim())
    throw userError(res.signal ? 'YouTube took too long to answer.' : explain(res.err));

  let data;
  try {
    data = JSON.parse(res.out);
  } catch {
    throw userError('I could not read the answer from YouTube.');
  }

  if (isUrl && data.entries)
    throw userError('Playlists and channels are not supported, send a single video link.');
  const v = data.entries ? data.entries[0] : data;
  if (!v) throw userError('I found no results for that search.');
  if (!/^[\w-]{11}$/.test(v.id ?? '')) throw userError('I could not find a playable video there.');
  if (v.live_status === 'is_live' || v.is_live) throw userError("Live streams aren't supported.");
  if (v.duration && v.duration > MAX_DURATION_S) throw userError('That video is longer than 3 hours.');

  return {
    url: `https://www.youtube.com/watch?v=${v.id}`,
    title: v.title ?? 'YouTube video',
    duration: v.duration ?? null,
  };
}

// Streams the audio of a video. onError is called with a readable message if yt-dlp fails.
async function streamAudio(url, onError) {
  await ensure();
  const args = [...baseArgs(), '-f', 'bestaudio[ext=webm]/bestaudio/best', '-o', '-', '--quiet', '--', url];
  const proc = spawn(BIN, args, { stdio: ['ignore', 'pipe', 'pipe'] });

  let stderr = '';
  let aborted = false;
  proc.stdout.on('error', () => {});
  proc.stderr.on('data', d => { if (stderr.length < 20000) stderr += d; });
  proc.on('error', e => onError?.(explainSpawn(e)));
  proc.on('close', code => {
    if (code !== 0 && !aborted) onError?.(explain(stderr));
  });

  return {
    stream: proc.stdout,
    abort: () => {
      aborted = true;
      proc.kill('SIGKILL');
    },
  };
}

module.exports = { isYoutubeUrl, getInfo, streamAudio };