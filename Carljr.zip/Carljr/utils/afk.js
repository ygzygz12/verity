const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'data', 'afk.json');
let cache = null;

function load() {
  if (cache) return cache;
  try {
    cache = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    cache = {};
  }
  return cache;
}

function save() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(cache, null, 2));
}

function setAfk(userId, reason) {
  load()[userId] = { reason, since: Date.now() };
  save();
}

function getAfk(userId) {
  return load()[userId] ?? null;
}

function removeAfk(userId) {
  const data = load();
  const entry = data[userId];
  if (!entry) return null;
  delete data[userId];
  save();
  return entry;
}

module.exports = { setAfk, getAfk, removeAfk };