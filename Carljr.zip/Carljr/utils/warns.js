const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'data', 'warns.json');

function load() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return {};
  }
}

function save(data) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function getWarns(guildId, userId) {
  return load()[guildId]?.[userId] ?? [];
}

function addWarn(guildId, userId, moderatorId, reason) {
  const data = load();
  data[guildId] ??= {};
  data[guildId][userId] ??= [];
  const list = data[guildId][userId];
  const id = list.length ? Math.max(...list.map(w => w.id)) + 1 : 1;
  list.push({ id, moderatorId, reason, date: Date.now() });
  save(data);
  return { id, total: list.length };
}

function removeWarn(guildId, userId, warnId) {
  const data = load();
  const list = data[guildId]?.[userId];
  if (!list) return false;
  const index = list.findIndex(w => w.id === warnId);
  if (index === -1) return false;
  list.splice(index, 1);
  save(data);
  return true;
}

function clearWarns(guildId, userId) {
  const data = load();
  const count = data[guildId]?.[userId]?.length ?? 0;
  if (count) {
    delete data[guildId][userId];
    save(data);
  }
  return count;
}

module.exports = { getWarns, addWarn, removeWarn, clearWarns };