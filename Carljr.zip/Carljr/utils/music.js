const fs = require('fs');
const path = require('path');
const dns = require('dns').promises;
const net = require('net');
const { Readable } = require('stream');
const { ChannelType } = require('discord.js');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  entersState,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  NoSubscriberBehavior,
  StreamType,
} = require('@discordjs/voice');
const ytdlp = require('./ytdlp');

const MUSIC_DIR = path.join(__dirname, '..', 'media', 'music');
const AUDIO_EXT = /\.(mp3|ogg|opus|wav|flac|m4a|aac|webm)$/i;
const MAX_QUEUE = 25;
const IDLE_LEAVE_MS = 5 * 60 * 1000;
const EMPTY_LEAVE_MS = 60 * 1000;

const sessions = new Map();
const pending = new Map();

// An error whose message is safe to show to users
const userError = msg => Object.assign(new Error(msg), { user: true });

function listFiles() {
  try {
    return fs.readdirSync(MUSIC_DIR).filter(f => AUDIO_EXT.test(f) && f.length <= 100);
  } catch {
    return [];
  }
}

function titleFromUrl(raw) {
  try {
    const u = new URL(raw);
    let last = u.pathname.split('/').filter(Boolean).pop() ?? '';
    try { last = decodeURIComponent(last); } catch { /* keep as is */ }
    return (last || u.hostname).slice(0, 80);
  } catch {
    return 'Stream';
  }
}

// ---------- Safe downloading (blocks local/private network addresses) ----------

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return (
      a === 0 || a === 10 || a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      a >= 224
    );
  }
  const v = ip.toLowerCase();
  if (v.startsWith('::ffff:')) {
    const rest = v.slice(7);
    return rest.includes('.') ? isPrivateIp(rest) : true;
  }
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') ||
    v.startsWith('fe8') || v.startsWith('fe9') || v.startsWith('fea') || v.startsWith('feb');
}

async function assertPublic(url) {
  if (url.protocol !== 'http:' && url.protocol !== 'https:')
    throw userError('Only http and https links are supported.');
  const host = url.hostname.replace(/^\[|\]$/g, '');
  let records;
  try {
    records = await dns.lookup(host, { all: true });
  } catch {
    throw userError('I could not find that server.');
  }
  if (!records.length || records.some(r => isPrivateIp(r.address)))
    throw userError('That address is not allowed.');
}

async function openStream(rawUrl) {
  let url = new URL(rawUrl);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    for (let hop = 0; hop <= 3; hop++) {
      await assertPublic(url);
      const res = await fetch(url, {
        redirect: 'manual',
        signal: controller.signal,
        headers: { 'User-Agent': 'Mozilla/5.0 (compatible; VerityBot)' },
      });

      const location = res.headers.get('location');
      if (res.status >= 300 && res.status < 400 && location) {
        res.body?.cancel().catch(() => {});
        url = new URL(location, url);
        continue;
      }
      if (!res.ok || !res.body) throw userError(`The server answered with status ${res.status}.`);

      const type = (res.headers.get('content-type') ?? '').toLowerCase();
      if (/mpegurl|scpls|m3u/.test(type) || /\.(m3u8?|pls)$/i.test(url.pathname))
        throw userError('Playlist links (.m3u / .pls) are not supported. Use the direct stream link.');
      if (type.startsWith('text/') || type.includes('html') || type.includes('json'))
        throw userError('That link is not an audio file or stream.');

      clearTimeout(timer);
      const stream = Readable.fromWeb(res.body);
      stream.on('error', () => {});
      return { stream, abort: () => controller.abort() };
    }
    throw userError('Too many redirects.');
  } catch (err) {
    clearTimeout(timer);
    controller.abort();
    if (err.user) throw err;
    if (err.name === 'AbortError') throw userError('The server took too long to answer.');
    console.error('Stream error:', err.message);
    throw userError('I could not connect to that link.');
  }
}

async function openTrack(track, session) {
  if (track.kind === 'file') {
    return { resource: createAudioResource(track.source, { inlineVolume: true }), cleanup: () => {} };
  }
  if (track.kind === 'youtube') {
    const { stream, abort } = await ytdlp.streamAudio(track.source, msg =>
      notify(session, `⚠️ Couldn't play **${track.title}**: ${msg}`)
    );
    return {
      resource: createAudioResource(stream, { inputType: StreamType.Arbitrary, inlineVolume: true }),
      cleanup: abort,
    };
  }
  const { stream, abort } = await openStream(track.source);
  return {
    resource: createAudioResource(stream, { inputType: StreamType.Arbitrary, inlineVolume: true }),
    cleanup: abort,
  };
}

// ---------- Sessions ----------

function notify(session, content) {
  session.textChannel?.send({ content, allowedMentions: { parse: [] } }).catch(() => {});
}

function destroySession(guildId) {
  const s = sessions.get(guildId);
  if (!s) return;
  sessions.delete(guildId);
  clearTimeout(s.idleTimer);
  clearTimeout(s.emptyTimer);
  s.queue = [];
  s.current = null;
  s.player.removeAllListeners();
  s.player.on('error', () => {});
  s.player.stop(true);
  s.cleanupCurrent?.();
  if (s.connection.state.status !== VoiceConnectionStatus.Destroyed) s.connection.destroy();
}

async function playNext(session, announce = true) {
  while (true) {
    if (sessions.get(session.guildId) !== session) return;
    clearTimeout(session.idleTimer);
    session.cleanupCurrent?.();
    session.cleanupCurrent = null;

    const track = session.queue.shift();
    if (!track) {
      session.current = null;
      session.idleTimer = setTimeout(() => {
        notify(session, '👋 Nothing left to play, leaving the voice channel.');
        destroySession(session.guildId);
      }, IDLE_LEAVE_MS);
      return;
    }

    session.current = track;
    session.opening = true;
    try {
      console.log(`[music] opening "${track.title}" (${track.kind})`);
      const { resource, cleanup } = await openTrack(track, session);
      if (sessions.get(session.guildId) !== session) {
        cleanup();
        return;
      }
      session.cleanupCurrent = cleanup;
      resource.volume?.setVolume(session.volume);
      session.player.play(resource);
      console.log(`[music] play() called for "${track.title}"`);
      if (announce) notify(session, `▶️ Now playing: **${track.title}**`);
      return;
    } catch (err) {
      console.error('Track error:', err.message);
      notify(session, `⚠️ Couldn't play **${track.title}**: ${err.user ? err.message : 'something went wrong while opening it.'}`);
    } finally {
      session.opening = false;
    }
    announce = true;
  }
}

async function buildSession(interaction, voiceChannel) {
  const guildId = voiceChannel.guild.id;
  const connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator,
    selfDeaf: true,
  });

  connection.on('stateChange', (oldState, newState) => {
    console.log(`[voice] ${oldState.status} -> ${newState.status}`);
  });
  connection.on('error', err => console.error('[voice error]', err.message));

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 20000);
  } catch {
    connection.destroy();
    throw userError('I could not connect to the voice channel in time. The host may be blocking voice connections.');
  }

  const player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } });
  connection.subscribe(player);

  const session = {
    guildId,
    connection,
    player,
    queue: [],
    current: null,
    opening: false,
    loop: 'off',        // 'off' | 'track' | 'queue'
    volume: 1,          // 0.01 - 1
    skipped: false,
    lastError: false,
    voiceChannelId: voiceChannel.id,
    textChannel: interaction.channel,
    cleanupCurrent: null,
    idleTimer: null,
    emptyTimer: null,
  };
  sessions.set(guildId, session);

  player.on('stateChange', (oldState, newState) => {
    console.log(`[player] ${oldState.status} -> ${newState.status}`);
  });

  player.on(AudioPlayerStatus.Idle, () => {
    const finished = session.current;
    let announce = true;

    // Loop handling: a track that failed is never repeated
    if (finished && !session.lastError) {
      if (session.loop === 'track' && !session.skipped) {
        session.queue.unshift(finished);
      } else if (session.loop === 'queue') {
        session.queue.push(finished);
      }
      if (session.queue.length === 1 && session.queue[0] === finished) announce = false;
    }
    session.skipped = false;
    session.lastError = false;
    playNext(session, announce);
  });

  player.on('error', err => {
    session.lastError = true;
    console.error('Audio player error:', err.message);
    notify(session, '⚠️ There was an audio error while playing. The owner can check the console.');
  });

  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    try {
      await Promise.race([
        entersState(connection, VoiceConnectionStatus.Signalling, 5000),
        entersState(connection, VoiceConnectionStatus.Connecting, 5000),
      ]);
    } catch {
      destroySession(guildId);
    }
  });
  connection.on(VoiceConnectionStatus.Destroyed, () => destroySession(guildId));

  return session;
}

function createSession(interaction, voiceChannel) {
  const guildId = voiceChannel.guild.id;
  if (sessions.has(guildId)) return Promise.resolve(sessions.get(guildId));
  if (!pending.has(guildId)) {
    pending.set(guildId, buildSession(interaction, voiceChannel).finally(() => pending.delete(guildId)));
  }
  return pending.get(guildId);
}

// Returns 0 if it starts right away, its queue position (1+) if it waits, -1 if the queue is full.
function addTrack(session, track) {
  if (session.queue.length >= MAX_QUEUE) return -1;
  session.queue.push(track);
  if (!session.current) {
    playNext(session, false);
    return 0;
  }
  return session.queue.length;
}

// ---------- Controls ----------

function skip(session) {
  session.skipped = true;
  const ok = session.player.stop();
  if (!ok) session.skipped = false;
  return ok;
}

function setLoop(session, mode) {
  session.loop = mode;
}

function setVolume(session, percent) {
  session.volume = percent / 100;
  session.player.state.resource?.volume?.setVolume(session.volume);
}

function shuffleQueue(session) {
  const q = session.queue;
  for (let i = q.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [q[i], q[j]] = [q[j], q[i]];
  }
  return q.length;
}

// position starts at 1. Returns the removed track or null.
function removeTrack(session, position) {
  if (position < 1 || position > session.queue.length) return null;
  return session.queue.splice(position - 1, 1)[0];
}

function clearQueue(session) {
  const count = session.queue.length;
  session.queue = [];
  return count;
}

// Approximate elapsed seconds of the current track
function elapsedSeconds(session) {
  const resource = session.player.state.resource;
  return resource ? Math.floor(resource.playbackDuration / 1000) : 0;
}

function getSession(guildId) {
  return sessions.get(guildId) ?? null;
}

function isPaused(session) {
  return session.player.state.status === AudioPlayerStatus.Paused;
}

// Checks that the user is in a usable voice channel and returns the session.
function checkUser(interaction, { needSession = false } = {}) {
  const channel = interaction.member?.voice?.channel;
  if (!channel) return { error: 'Join a voice channel first.' };
  if (channel.type !== ChannelType.GuildVoice)
    return { error: 'Stage channels are not supported, use a normal voice channel.' };
  const session = sessions.get(interaction.guild.id) ?? null;
  if (session && session.voiceChannelId !== channel.id)
    return { error: `I'm already in <#${session.voiceChannelId}>. Join that channel to control me.` };
  if (!session && needSession) return { error: "I'm not playing anything right now." };
  return { channel, session };
}

// Leaves 60 seconds after the last human leaves the voice channel.
function onVoiceUpdate(oldState) {
  const guild = oldState.guild;
  const session = sessions.get(guild.id);
  if (!session) return;

  const humans = guild.voiceStates.cache.filter(s =>
    s.channelId === session.voiceChannelId && s.id !== guild.client.user.id && !s.member?.user.bot
  ).size;

  if (humans === 0) {
    session.emptyTimer ??= setTimeout(() => {
      notify(session, '👋 Everyone left, so I left too.');
      destroySession(guild.id);
    }, EMPTY_LEAVE_MS);
  } else if (session.emptyTimer) {
    clearTimeout(session.emptyTimer);
    session.emptyTimer = null;
  }
}

module.exports = {
  MUSIC_DIR, MAX_QUEUE, listFiles, titleFromUrl, createSession, addTrack,
  skip, setLoop, setVolume, shuffleQueue, removeTrack, clearQueue, elapsedSeconds,
  getSession, destroySession, isPaused, checkUser, onVoiceUpdate,
};