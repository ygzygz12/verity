const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', 'data', 'xp.json');
const COOLDOWN_MS = 60 * 1000;
const XP_MIN = 15;
const XP_MAX = 25;

let cache = null;
let dirty = false;
const lastGain = new Map();

function load() {
  if (cache) return cache;
  try {
    cache = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    cache = {};
  }
  return cache;
}

function flush() {
  if (!dirty || !cache) return;
  try {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(cache));
    dirty = false;
  } catch (err) {
    console.error('XP save error:', err.message);
  }
}

// Saves every 30 seconds (not on every message) and when the bot stops.
setInterval(() => {
  flush();
  const now = Date.now();
  for (const [key, time] of lastGain) if (now - time > COOLDOWN_MS) lastGain.delete(key);
}, 30000).unref();
process.on('exit', flush);
process.on('SIGINT', () => { flush(); process.exit(0); });
process.on('SIGTERM', () => { flush(); process.exit(0); });

// XP needed to go from `level` to `level + 1`
function xpForLevel(level) {
  return 5 * level * level + 50 * level + 100;
}

// Total XP needed to reach `level` from zero
function totalXpForLevel(level) {
  let total = 0;
  for (let i = 0; i < level; i++) total += xpForLevel(i);
  return total;
}

function levelInfo(totalXp) {
  let level = 0;
  let remaining = totalXp;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level++;
  }
  return { level, current: remaining, needed: xpForLevel(level) };
}

function addXp(guildId, userId) {
  const key = `${guildId}:${userId}`;
  const now = Date.now();
  if (now - (lastGain.get(key) ?? 0) < COOLDOWN_MS) return null;
  lastGain.set(key, now);

  const data = load();
  data[guildId] ??= {};
  const u = (data[guildId][userId] ??= { xp: 0, messages: 0 });

  const before = levelInfo(u.xp).level;
  const gain = XP_MIN + Math.floor(Math.random() * (XP_MAX - XP_MIN + 1));
  u.xp += gain;
  u.messages += 1;
  dirty = true;

  const after = levelInfo(u.xp).level;
  return { gain, level: after, leveledUp: after > before };
}

// Sets the total XP of a user (owner command). Returns the new level info.
function setXp(guildId, userId, xp) {
  const data = load();
  data[guildId] ??= {};
  const u = (data[guildId][userId] ??= { xp: 0, messages: 0 });
  u.xp = Math.max(0, Math.floor(xp));
  dirty = true;
  flush();
  return levelInfo(u.xp);
}

function getUser(guildId, userId) {
  const guild = load()[guildId] ?? {};
  const u = guild[userId] ?? { xp: 0, messages: 0 };
  const rank = Object.values(guild).filter(other => other.xp > u.xp).length + 1;
  return { ...u, ...levelInfo(u.xp), rank, hasData: Boolean(guild[userId]) };
}

function top(guildId, limit = 10) {
  const guild = load()[guildId] ?? {};
  return Object.entries(guild)
    .map(([id, u]) => ({ id, xp: u.xp, level: levelInfo(u.xp).level }))
    .sort((a, b) => b.xp - a.xp)
    .slice(0, limit);
}

module.exports = { addXp, setXp, getUser, top, levelInfo, xpForLevel, totalXpForLevel };