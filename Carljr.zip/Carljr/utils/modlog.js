const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');

const FILE = path.join(__dirname, '..', 'data', 'settings.json');

function load() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return {};
  }
}

function save(data) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function setLogChannel(guildId, channelId) {
  const data = load();
  data[guildId] ??= {};
  if (channelId) data[guildId].logChannel = channelId;
  else delete data[guildId].logChannel;
  save(data);
}

function getLogChannel(guildId) {
  return load()[guildId]?.logChannel ?? null;
}

const fmtUser = user => `${user.tag} (${user.id})`;

// Never throws: a broken log channel must not break the command itself.
async function logAction(interaction, { action, color = 0x5865f2, target, reason, details }) {
  try {
    const guild = interaction.guild;
    if (!guild) return;
    const channelId = getLogChannel(guild.id);
    if (!channelId) return;
    const channel = await guild.channels.fetch(channelId).catch(() => null);
    if (!channel?.isTextBased()) return;

    const fields = [
      { name: 'Moderator', value: fmtUser(interaction.user) },
    ];
    if (target) fields.unshift({ name: 'Target', value: target });
    if (reason) fields.push({ name: 'Reason', value: reason.slice(0, 1000) });
    if (details) fields.push({ name: 'Details', value: details.slice(0, 1000) });

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(action)
      .addFields(fields)
      .setTimestamp();

    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch (err) {
    console.error('Mod-log error:', err.message);
  }
}

module.exports = { setLogChannel, getLogChannel, logAction, fmtUser };